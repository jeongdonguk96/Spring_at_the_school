package constructor_injection;

public class Spike implements Weapon {

	public Spike() {}
	
	@Override
	public void useWeapon() {
		System.out.println("Use Spike");
	}

}
