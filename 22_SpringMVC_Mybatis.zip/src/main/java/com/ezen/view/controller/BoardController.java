package com.ezen.view.controller;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.ezen.biz.board.BoardService;
import com.ezen.biz.dto.BoardVO;

@Controller
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	/*
	 * 글 등록 기능
	 */
	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO vo) throws IllegalStateException, IOException {
		
		// 파일 업로드 처리
		MultipartFile uploadFile = vo.getUploadFile();
		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			System.out.println("fileName="+fileName);
			uploadFile.transferTo(new File("D:\\SpringWorkspace\\upload\\"+fileName));
		}
		
		boardService.insertBoard(vo);
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 수정 기능
	 * @ModelAttribute - 세션 내장객체에 저장된 내용이 vo 객체에 저장됨
	 */
	@RequestMapping("/updateBoard.do")
	public String updateBoard(@ModelAttribute("board") BoardVO vo) {
		System.out.println("작성자 이름: " + vo.getWriter());
		boardService.updateBoard(vo);
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 삭제 기능
	 */
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(BoardVO vo) {

		boardService.deleteBoard(vo);
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 상세 조회
	 */
	@RequestMapping("/getBoard.do")
	public String getBoard(BoardVO vo, Model model) {

		BoardVO board = boardService.getBoard(vo);
		
		// 응답 화면구성
		
		// @SessionAttributes 사용 시, 
		// model 객체에 저장됨과 공시에 session 내장객체에도 저장됨.
		model.addAttribute("board", board);
		
		return "getBoard.jsp";
	}
	
	/*
	 * 검색조건 목록값을 내장객체에 저장
	 */
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new LinkedHashMap<>();
		
		conditionMap.put("제목", "TITLE");
		conditionMap.put("내용", "CONTENT");
		
		return conditionMap;
	}
	
	/*
	 * 글 목록 조회
	 */
	@RequestMapping(value="/getBoardList.do")
	public String getBoardList(
			//@RequestParam(value="searchCondition", defaultValue="TITLE", required=false) String condition,
			//@RequestParam(value="searchKeyword", defaultValue="", required=false) String keyword,
			BoardVO vo,
			Model model) {
		
		if (vo.getSearchCondition() == null) vo.setSearchCondition("TITLE");
		if (vo.getSearchKeyword() == null) vo.setSearchKeyword("");
		
		System.out.println("검색 조건: " + vo.getSearchCondition());
		System.out.println("검색 키워드: " + vo.getSearchKeyword());
		
		// 게시글을 DB에서 조회
		List<BoardVO> boardList = boardService.getBoardList(vo);
		
		// 검색결과를 request 객체에 저장하고 jsp 화면 호출
		model.addAttribute("boardList", boardList);
		
		return "getBoardList.jsp";
	}
}






