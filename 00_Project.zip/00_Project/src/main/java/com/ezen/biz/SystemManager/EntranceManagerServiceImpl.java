package com.ezen.biz.SystemManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.EntranceManagerDAO;
import com.ezen.biz.dto.EntranceManagerVO;

@Service("entranceService")
public class EntranceManagerServiceImpl implements EntranceManagerService {
	
	@Autowired
	private EntranceManagerDAO entranceManagerDAO;
	
	public EntranceManagerServiceImpl() {}
	
	@Override
	public void registerEntranceTime(EntranceManagerVO entranceManager) {
		entranceManagerDAO.registerEntranceTime(entranceManager);
	}

}
