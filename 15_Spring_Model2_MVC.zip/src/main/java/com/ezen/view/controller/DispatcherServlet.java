package com.ezen.view.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DispatcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HandlerMapping handlerMapping;
	private ViewResolver viewResolver;
	
	/*
	 * 서블릿 객체가 생성된 후 멤버변수를 초기화하기 위해 자동으로 실행
	 */
	@Override
	public void init() throws ServletException {
		handlerMapping = new HandlerMapping();
		viewResolver = new ViewResolver();
		
		viewResolver.setPrefix("./");
		viewResolver.setSuffix(".jsp");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. 클리이언트 요청 path 정보를 추출한다. 마지막 "/" 뒤의 요청 command를 분리해서 path로 저장
		String uri = request.getRequestURI(); // uri : 쿼리스트링을 뺀 부분
		String path = uri.substring(uri.lastIndexOf("/")); // uri에서 마지막 '/'의 이후 부분을 path로 저장
		System.out.println("path(=command) = " + path);		
		
		// 2. HandlerMapping에서 path(요청)에 해당하는 Controller 검색
		Controller controller = handlerMapping.getController(path);
		
		// 3. Controller 실행
		String viewName = controller.handleRequest(request, response);
		
		// 4. ViewResolver를 통해 view 경로 완성
		String view = "";
		
		if(viewName.contains(".do")) { // .do 요청이라 경로를 만들 필요가 없음
			view = viewName;
		} else { // 경로를 만들어 줘야 함
			view = viewResolver.getView(viewName);
		}
		
		// 5. view 화면을 응답
		response.sendRedirect(view);
	}
}
