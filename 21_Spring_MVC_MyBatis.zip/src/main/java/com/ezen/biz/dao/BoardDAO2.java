package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.BoardVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("boardDAO2")
public class BoardDAO2 {

	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 글 등록 매서드
	public void insertBoard(BoardVO board) {
		System.out.println("===> MyBatis로 insertBoard() 처리");
		   				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.insert("boardMapper.insertBoard", board);
	}
	
	// 글 수정 매서드
	public void updateBoard(BoardVO board) {
		System.out.println("===> MyBatis로 updateBoard() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.update("boardMapper.updateBoard", board);
	}
	
	// 글 삭제 매서드
	public void deleteBoard(BoardVO board) {
		System.out.println("===> MyBatis로 deleteBoard() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.delete("boardMapper.deleteBoard", board);
	}
	
	// 글 전체 조회 매서드
	public List<BoardVO> getBoardList(BoardVO board) {
		System.out.println("===> MyBatis로 getBoardList() 처리");
									  // ("실행될 sql문의 id", returnType으로 지정된 객체)
		return myBatis.selectList("boardMapper.getBoardList", board);
	}
	
	// 글 상세 조회 매서드
	public BoardVO getBoard(BoardVO board) {
		System.out.println("===> MyBatis로 getBoard() 처리");
				  					 // ("실행될 sql문의 id", returnType으로 지정된 객체)
		return myBatis.selectOne("boardMapper.getBoard", board);
		
	}
}















