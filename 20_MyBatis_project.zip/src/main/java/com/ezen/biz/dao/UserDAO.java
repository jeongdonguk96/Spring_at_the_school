package com.ezen.biz.dao;

import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.UserVO;

@Repository("userDAO")
public class UserDAO {

	public UserVO getUser(UserVO vo) {
		
		return vo;		
	}
}
