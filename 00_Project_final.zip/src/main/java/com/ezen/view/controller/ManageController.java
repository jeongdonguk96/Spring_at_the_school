package com.ezen.view.controller;

import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;
import com.ezen.biz.user.UserCheckService;
import com.ezen.biz.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class ManageController {
	
    @Autowired
    UserCheckService userCheckService;
    @Autowired
    UserService userService;

    @RequestMapping("/manage.do")
    public String managePage(UserVO user, Model model) throws Exception {
    	
    	// 오늘 출석한 사람들(퇴실 시간이 오늘인 사람들) 조회
    	List<UserCheckVO> todayList = userCheckService.getTodayList();
    	// 모든 사용자 조회
    	List<UserVO> attendList = userService.readAll();
    	//System.out.println("attendList = " + attendList);


    	model.addAttribute("todayList",todayList);
    	model.addAttribute("attendList",attendList);
    	model.addAttribute("user",user);
    	
    	return "manage.jsp";
    }

    @PostMapping("/commit.do")
    public String read(String id, UserVO user, Model model, HttpSession session, HttpServletRequest request) throws Exception {
    	user.setId(id);

        // 출결 판별 + 출결 정보 업데이트 메서드
        userCheckService.attendCommit();

        return "redirect:/manage.do";
    }


}
