package com.ezen.biz.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.board.common.Log4jAdvice;
import com.ezen.biz.board.common.LogAdvice;
import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dto.BoardVO;

@Service("boardService")
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardDAO boardDAO;
	// private LogAdvice log;
	// private Log4jAdvice log;
	
	public BoardServiceImpl() {
		// log = new LogAdvice();
		// log = new Log4jAdvice();
	}

	@Override
	public void insertBoard(BoardVO board) {
		// log.printLog();
		// log.printLogging();
		boardDAO.insertBoard(board);
	}

	@Override
	public void updateBoard(BoardVO board) {
		// log.printLog();
		// log.printLogging();
		boardDAO.updateBoard(board);
	}

	@Override
	public void deleteBoard(BoardVO board) {
		// log.printLog();
		// log.printLogging();
		boardDAO.deleteBoard(board);
	}

	@Override
	public List<BoardVO> getBoardList() {
		// log.printLog();
		// log.printLogging();
		return boardDAO.getBoardList();
	}

	@Override
	public BoardVO getBoard(BoardVO board) {
		// log.printLog();
		// log.printLogging();
		return boardDAO.getBoard(board);
	}

}
