package com.ezen.biz.board;

import java.util.List;

import com.ezen.biz.dto.BoardVO;

public interface BoardService {
	// 게시판 조회
	List<BoardVO> getBoardList(BoardVO board);
	
	// 게시글 조회
	BoardVO getBoard(BoardVO board);

	// 게시글 작성
	void insertBoard(BoardVO board);
	
	// 게시글 수정
	void updateBoard(BoardVO board);
	
	// 게시글 삭제
	void deleteBoard(BoardVO board);
}
