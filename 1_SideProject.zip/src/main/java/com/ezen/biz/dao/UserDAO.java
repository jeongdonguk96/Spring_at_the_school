package com.ezen.biz.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.UserVO;

@Repository("userDAO")
public class UserDAO {
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 로그인
	public UserVO getUser(UserVO user) {
		System.out.println("==> MyBatis로 getUser() 처리");
		
		return myBatis.selectOne("userMapper.getUser", user);
	}
	
	// 회원가입
	public void insertUser(UserVO user) {
		System.out.println("==> MyBatis로 insertUser() 처리");
		
		myBatis.insert("userMapper.insertUser", user);
	}
	
	// 회원정보 수정
	public void updateUser(UserVO user) {
		System.out.println("==> MyBatis로 updateUser() 처리");
		
		myBatis.update("userMapper.updateUser", user);
	}
	
	// 아이디 수정
	public void updateId(UserVO user) {
		System.out.println("==> MyBatis로 updateId() 처리");
		
		myBatis.update("userMapper.updateId", user);
	}
	
	// 비밀번호 수정
	public void updatePwd(UserVO user) {
		System.out.println("==> MyBatis로 updatePwd() 처리");
		
		myBatis.update("userMapper.updatePwd", user);
	}
	
	// 회원탈퇴
	public void deleteUser(UserVO user) {
		System.out.println("==> MyBatis로 deleteUser() 처리");
		
		myBatis.update("userMapper.deleteUser", user);
	}
}
