package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("userDAO")
public class UserDAO {

	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 로그인
	public UserVO login(UserVO user) {
		System.out.println("===> MyBatis로 login() 처리");
		   			// ("실행될 sql문의 id", resultType으로 지정된 객체)
		return myBatis.selectOne("userMapper.login", user);
	}
	
	// 로그아웃
	public void logout() {
		System.out.println("===> MyBatis로 logout() 처리");

	}
	
	// 회원가입
	public void insertUser(UserVO user) {
		System.out.println("===> MyBatis로 insertUser() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.insert("userMapper.insertUser", user);
	}
	
	// 회원정보 수정
	public void updateUser(UserVO user) {
		System.out.println("===> MyBatis로 updateUser() 처리");
		System.out.println("user = " + user);
				// ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.update("userMapper.updateUser", user);
	}
	
	// 회원탈퇴
	public void deleteUser(UserVO user) {
		System.out.println("===> MyBatis로 deleteUser() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.delete("userMapper.deleteUser", user);
	}
		
	// 회원 출결정보 조회
	public UserVO getUserInfo(UserVO user) {
		System.out.println("===> MyBatis로 getUserInfo() 처리");
		
		return myBatis.selectOne("userMapper.getUserInfo", user);
	}
	
	// 회원 최근 입실시간 조회
	public UserCheckVO getLatestEntry(UserVO user) {
		System.out.println("===> MyBatis로 getLatestEntry() 처리");
		
		return myBatis.selectOne("userMapper.getLatestEntry", user);
	}
	
	// 회원 최근 퇴실시간 조회
	public UserCheckVO getLatestOut(UserVO user) {
		System.out.println("===> MyBatis로 getLatestOut() 처리");
		
		return myBatis.selectOne("userMapper.getLatestOut", user);
	}
	
	// 출결 관련
    public int upAttendance(String id) throws Exception {
    	System.out.println("[출석] "+id);
        return myBatis.update("userMapper.updateAttendance",id);
    }

    public int upLate(String id) throws Exception {
    	System.out.println("[지각] "+id);
        return myBatis.update("userMapper.updateLate",id);
    }

    public int upEarlyLeave(String id) throws Exception {
    	System.out.println("[조퇴] "+id);
        return myBatis.update("userMapper.updateEarlyLeave",id);
    }

    public int upAbsence(String id) throws Exception {
        System.out.println("[결석] "+id);
        return myBatis.update("userMapper.updateAbsence",id);
    }
    
    // 모든 사용자 조회(role = 'user')
    public List<UserVO> selectAllUser() throws Exception {
        return myBatis.selectList("userMapper.selectAllUser");
    }
    
    // 사용자 조회
    public UserVO selectUser(String id) throws Exception {
        return myBatis.selectOne("userMapper.select", id);
    }
    
    // 관리자 조회
    public UserVO selectAdmin(String id) throws Exception {
        return myBatis.selectOne("userMapper.selectAdmin",id);
    }

}
