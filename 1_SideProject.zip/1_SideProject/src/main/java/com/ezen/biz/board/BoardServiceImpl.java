package com.ezen.biz.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dto.BoardVO;

@Service("boardService")
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardDAO boardDAO;
	
	/// 게시판 조회
	@Override
	public List<BoardVO> getBoardList(BoardVO board) {
		return boardDAO.getBoardList(board);
	}
	
	// 게시글 조회
	@Override
	public BoardVO getBoard(BoardVO board) {
		return boardDAO.getBoard(board);
	}

	// 게시글 작성
	@Override
	public void insertBoard(BoardVO board) {
		boardDAO.insertBoard(board);
	}
	
	// 게시글 수정
	@Override
	public void updateBoard(BoardVO board) {
		boardDAO.updateBoard(board);
	}
	
	// 게시글 삭제
	@Override
	public void deleteBoard(BoardVO board) {
		boardDAO.deleteBoard(board);
	}
}
