package com.ezen.biz.user;

import com.ezen.biz.dto.UserVO;

public interface UserService {

	// 개별 사용자 조회 매서드
	UserVO getUser(UserVO user);

}