package constructor_injection;

public class Gun implements Weapon {

	public Gun() {}
	
	@Override
	public void useWeapon() {
		System.out.println("Use Gun");
	}

}
