package com.ezen.biz.board;

import java.util.List;

import com.ezen.biz.dto.BoardVO;

public interface BoardService {

	// 글 등록 매서드
	void insertBoard(BoardVO board);

	// 글 수정 매서드
	void updateBoard(BoardVO board);

	// 글 삭제 매서드
	void deleteBoard(BoardVO board);

	// 글 전체 조회 매서드
	List<BoardVO> getBoardList(BoardVO board);

	// 글 상세 조회 매서드
	BoardVO getBoard(BoardVO board);

}