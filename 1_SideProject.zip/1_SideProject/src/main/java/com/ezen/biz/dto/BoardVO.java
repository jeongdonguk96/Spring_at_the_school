package com.ezen.biz.dto;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

public class BoardVO {
	private String seq; /* 글번호 */
	private String tab; /* 탭 */
	private String title; /* 제목 */
	private String writer; /* 작성자 */
	private String content; /* 내용 */
	private Date regDate; /* 작성일 */
	private String count; /* 조회수 */
	private String recommendation; /* 추천수 */
	private String searchCondition; /* 검색조건 */
	private String searchKeyword; /* 검색내용 */
	private MultipartFile uploadFile; /* 파일 */
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTab() {
		return tab;
	}
	public void setTab(String tab) {
		this.tab = tab;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}
	public String getSearchCondition() {
		return searchCondition;
	}
	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}
	public String getSearchKeyword() {
		return searchKeyword;
	}
	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}
	public MultipartFile getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}
	
	@Override
	public String toString() {
		return "BoardVO [seq=" + seq + ", tab=" + tab + ", title=" + title + ", writer=" + writer + ", content="
				+ content + ", regDate=" + regDate + ", count=" + count + ", recommendation=" + recommendation
				+ ", uploadFile=" + uploadFile + "]";
	}
}
