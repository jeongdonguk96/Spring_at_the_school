package com.ezen.biz;

public interface Speaker {
	public void volumeUp();
	public void volumeDown();
}
