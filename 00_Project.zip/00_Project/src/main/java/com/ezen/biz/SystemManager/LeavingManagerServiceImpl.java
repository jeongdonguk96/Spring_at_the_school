package com.ezen.biz.SystemManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.EntranceManagerDAO;
import com.ezen.biz.dao.LeavingManagerDAO;
import com.ezen.biz.dto.EntranceManagerVO;
import com.ezen.biz.dto.LeavingManagerVO;

@Service("leavingService")
public class LeavingManagerServiceImpl implements LeavingManagerService {
	
	@Autowired
	private LeavingManagerDAO leavingManagerDAO;
	
	public LeavingManagerServiceImpl() {}
	
	@Override
	public void registerLeavingTime(LeavingManagerVO leavingManager) {
		leavingManagerDAO.registerLeavingTime(leavingManager);
	}

}
