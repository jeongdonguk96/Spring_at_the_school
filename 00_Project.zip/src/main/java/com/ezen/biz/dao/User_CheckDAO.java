package com.ezen.biz.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.User_CheckVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("user_CheckDAO")
public class User_CheckDAO {
	
	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
		
	// 입실등록
	public void setInTime(User_CheckVO user_Check) {
		myBatis.insert("user-checkMapper.setInTime", user_Check);
	}
	
	// 입실 업데이트
	public void updateInTime(User_CheckVO user_Check) {
		myBatis.insert("user-checkMapper.updateInTime", user_Check);
	}
	
	// 입실등록
	public void setOutTime(User_CheckVO user_Check) {
		myBatis.insert("user-checkMapper.setOutTime", user_Check);
	}
	
	// 퇴실 업데이트
	public void updateOutTime(User_CheckVO user_Check) {
		myBatis.insert("user-checkMapper.updateOutTime", user_Check);
	}
	
	// 회원 최근입실시간 조회
	public User_CheckVO getLatestInTime(User_CheckVO user_Check) {
		System.out.println("===> MyBatis로 getLatestInTime() 처리");
		
		return myBatis.selectOne("user-checkMapper.getLatestInTime", user_Check);
	}
	
	// 회원 최근퇴실시간 조회
	public User_CheckVO getLatestOutTime(User_CheckVO user_Check) {
		System.out.println("===> MyBatis로 getLatestOutTime() 처리");
		
		return myBatis.selectOne("user-checkMapper.getLatestOutTime", user_Check);
	}
}
