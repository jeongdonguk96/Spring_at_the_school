package collection_inject;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/*
 * 컬렉션의 경우 게터와 세터 둘 다 생성해준다.
 * xml파일에서 set해준 후 main매서드에서 get하는 방식,
 * 그리고 향상된 for문으로 꺼내면 됨
 */
public class CollectionBean {
	private List<String> addressList;
	private List<Book> bookList;
	private Set<String> movieList;
	private Map<String, String> prefList;
	private Properties propList;
	
	public List<String> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<String> addressList) {
		this.addressList = addressList;
	}

	public List<Book> getBookList() {
		return bookList;
	}

	public void setBookList(List<Book> bookList) {
		this.bookList = bookList;
	}

	public Set<String> getMovieList() {
		return movieList;
	}

	public void setMovieList(Set<String> movieList) {
		this.movieList = movieList;
	}

	public Map<String, String> getPrefList() {
		return prefList;
	}

	public void setPrefList(Map<String, String> prefList) {
		this.prefList = prefList;
	}

	public Properties getPropList() {
		return propList;
	}

	public void setPropList(Properties propList) {
		this.propList = propList;
	}
}

