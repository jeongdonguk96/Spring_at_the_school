package com.ezen.biz.common;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

@Service
@Aspect // 위빙의 역할
public class AfterThrowingAdvice {
	// @Pointcut("execution(* com.ezen.biz..*Impl.*(..))") // 포인트컷 생성
	// public void allPointCut() {}
	
	@AfterThrowing(pointcut="PointCutCommon.allPointCut()", throwing="exceptObj") // 포인트컷 지정, 예외 지정
	public void exceptionLog(JoinPoint jp, Exception exceptObj) { // exceptObj는 jp 실행 때 생긴 예외를 의미 
																  // xml파일에 별도로 throwing="exceptObj" 지정 (예외를 exceptObj에 담겠다는 의미)
		String method = jp.getSignature().getName(); // jp의 정보를 불러오고 그 중 매서드이름을 반환
		
		System.out.printf("[예외 처리]%s() 비즈니스 로직 수행 중 예외 발생 : %s\n", method, exceptObj.getMessage());
	}
}
