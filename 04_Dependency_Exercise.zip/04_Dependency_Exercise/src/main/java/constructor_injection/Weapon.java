package constructor_injection;

public interface Weapon {
	public void useWeapon();
}
