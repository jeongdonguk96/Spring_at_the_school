package com.ezen.biz.user;

import java.util.List;

import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;

public interface UserService {
	
	// 로그인
	UserVO login(UserVO user);
	
	// 로그아웃
	void logout();
	
	// 회원가입
	void insertUser(UserVO user);
	
	// 회원정보수정
	void updateUser(UserVO user);
	
	// 회원탈퇴
	void deleteUser(UserVO user);
	
	// 회원 정보 조회
	UserVO getUserInfo(UserVO user);
	
	// 최근 입실시간 조회
	UserCheckVO getLatestEntry(UserVO user);
	
	// 최근 퇴실시간 조회
	UserCheckVO getLatestOut(UserVO user);
	
	// 로그인 id,pwd 검증
	UserVO read(String id) throws  Exception;
	UserVO readAdmin(String id) throws Exception;
    List<UserVO> readAll() throws Exception;

}