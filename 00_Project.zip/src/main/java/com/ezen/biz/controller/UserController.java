package com.ezen.biz.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.biz.dto.UserVO;
import com.ezen.biz.dto.User_CheckVO;
import com.ezen.biz.user.UserService;
import com.ezen.biz.user_Check.User_CheckService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private User_CheckService user_CheckService;
	
	/*
	 * 로그인
	 */
	@PostMapping("/login.do")
	public String login(UserVO uservo, User_CheckVO user_Check, HttpSession session) {
		UserVO user = userService.login(uservo);
		
		if(user != null) { // 로그인 성공 시
			if(user.getRole().equals("admin")) { // 관리자 로그인 시
				session.setAttribute("admin", user);
				System.out.println("관리자 로그인 처리 완료 \n");
				return "admin.jsp";
			}
			session.setAttribute("user", user); // 유저 정보 세션에 저장
			
			UserVO userInfos = userService.getUserInfo(user);
			session.setAttribute("userInfo", userInfos); // 유저 출결정보 세션에 저장
			
			User_CheckVO latestInTime = user_CheckService.getLatestInTime(user_Check); // 유저 최근 입실시간 세션에 저장
			session.setAttribute("userInTime", latestInTime);
			
			User_CheckVO latestOutTime = user_CheckService.getLatestOutTime(user_Check); // 유저 최근 퇴실시간 세션에 저장
			session.setAttribute("userOutTime", latestOutTime);
			
			System.out.println("로그인 처리 성공 \n");
			return "main.jsp";
		} else { 		   // 로그인 실패 시
			System.out.println("로그인 처리 실패 \n");
			return "login.jsp";
		}
	}
	
	/*
	 * 로그아웃
	 */
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "main.jsp";
	}
	
	/*
	 * 회원가입
	 */
	@PostMapping("/join.do")
	public String join(UserVO user) {
		userService.joinUser(user);
		
		return "main.jsp";
	}

	/*
	 * 회원정보 수정
	 */
	@PostMapping("/update.do")
	public String updateUser(UserVO user, HttpSession session) {
		userService.updateUser(user);
	
		session.setAttribute("user", user);
		System.out.println("회원정보 수정 처리 성공 \n");
		
		return "main.jsp";
	}
	
	/*
	 * 회원탈퇴
	 */
	@PostMapping("/delete.do")
	public String deleteUser(UserVO user) {
		userService.deleteUser(user);
		System.out.println("회원탈퇴 처리 성공 \n");
		
		return "main.jsp";
	}
}
