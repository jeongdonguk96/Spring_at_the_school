package com.ezen.view.controller;

/*
 * Controller가 리턴한 View 이름에 접두사, 접미사를 결합해 최종 실행될 View 경로와 파일명을 완성
 * DispatcherSerlvet의 init() 매서드가 호출될 때 생성
 */
public class ViewResolver {
	public String prefix;
	public String suffix;
	
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	
	public String getView(String viewName) {
		return prefix + viewName + suffix;
	}
}
