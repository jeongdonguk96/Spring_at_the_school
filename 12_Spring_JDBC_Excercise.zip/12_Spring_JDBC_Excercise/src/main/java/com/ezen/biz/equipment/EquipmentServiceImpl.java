package com.ezen.biz.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.EquipmentDAO;
import com.ezen.biz.dto.EquipmentVO;

@Service("equipmentService")
public class EquipmentServiceImpl implements EquipmentService {
	
	@Autowired
	private EquipmentDAO equipmentDAO;
	
	public void insertEquipment(EquipmentVO equip) {
		equipmentDAO.insertEquipment(equip);
	}
	
	public int updateEquipmentById(EquipmentVO equip) {
		return equipmentDAO.updateEquipmentById(equip);
		
	}
		
	public int deleteEquipmentById(EquipmentVO equip) {
		return equipmentDAO.deleteEquipmentById(equip);		
	}
	
}
