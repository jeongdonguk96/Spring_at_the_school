package com.ezen.biz.user;

import java.util.List;

import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;

public interface UserCheckService {
	
	// 입실 등록
	int checkIn(UserCheckVO attendDto) throws Exception;
    
	// 퇴실 등록
	int checkOut(UserCheckVO attendDto) throws Exception;

	// 사용자 출결처리(관리자 기능)
    List<UserVO> attendCommit() throws Exception;

    // 오늘 입실정보 조회
    UserCheckVO readCheckIn(String id) throws Exception;

    // 오늘 퇴실정보 조회
    UserCheckVO readCheckOut(String id) throws Exception;

    // 출결처리(출석/지각/조퇴/결석 판별) 
    int checkAttend(String id) throws Exception;

    // 오늘 날짜에 출석한 사람 조회
    List<UserCheckVO> getTodayList() throws Exception;
    
    // 전체 입실/퇴실 정보 조회
    List<UserCheckVO> getAllDayList() throws Exception;

}
