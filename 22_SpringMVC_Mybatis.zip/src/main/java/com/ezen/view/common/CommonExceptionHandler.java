package com.ezen.view.common;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

/*
 * com.ezen.view 패키지 아래에서 예이 발생시 @ExceptionHandler로 지정한 메소드가 실행됨.
 */
/*
@ControllerAdvice("com.ezen.view")
public class CommonExceptionHandler {

	@ExceptionHandler(ArithmeticException.class)
	public ModelAndView handleArithmeticException(Exception e) {
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("exception", e);
		modelView.setViewName("/common/arithmeticError.jsp");
		return modelView;
	}
	
	@ExceptionHandler(NullPointerException.class)
	public ModelAndView handleNullPointerException(Exception e) {
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("exception", e);
		modelView.setViewName("/common/nullPointerError.jsp");
		return modelView;
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception e) {
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("exception", e);
		modelView.setViewName("/common/error.jsp");
		return modelView;
	}
}
*/
