package com.ezen.biz;

public class LgTV implements TV {

	public LgTV() {
		System.out.println("LgTV 객체를 생성합니다.");
	}
	
	public void initMethod() {
		System.out.println("객체 초기화 작업 처리...");
	}
	
	public void destroyMethod() {
		System.out.println("객체 삭제 전 처리할 로직 실행...");
	}
	
	@Override
	public void powerOn() {
		System.out.println("LgTv -- 전원을 켭니다");
	}

	@Override
	public void powerOff() {
		System.out.println("LgTv -- 전원을 끕니다");
	}

	@Override
	public void volumeUp() {
		System.out.println("LgTv -- 볼륨을 올립니다");
	}

	@Override
	public void volumeDown() {
		System.out.println("LgTv -- 볼륨을 내립니다");
	}

}
