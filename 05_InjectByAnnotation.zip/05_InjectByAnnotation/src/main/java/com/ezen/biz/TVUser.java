package com.ezen.biz;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {
		// 1. 스프링 컨테이너를 구동
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		
		// 2. 스프링 컨테이너에 필요한 객체 요청
		TV tv = (TV)factory.getBean("tv");

		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		
		factory.close();
		
		/*
		Speaker speaker = (Speaker) factory.getBean("jbl");
		
		speaker.volumeUp();
		speaker.volumeDown();
		
		factory.close();
		*/
	}

}
