package com.ezen.biz.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ezen.biz.board.BoardService;
import com.ezen.biz.dto.BoardVO;

@Controller
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardService;
	/*
	 * 검색 조건 목록 생성 - 동적으로 이용하기 위함(model 내장객체에 정보를 담아 .jsp에서 사용)
	 * 여기선 매서드의 리턴값을 "conditionMap"이라는 이름의 model 내장객체에 저장
	 */
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new LinkedHashMap<>();
		
		// 이 맵에 put하는 갯수만큼 jsp에서 forEach로 꺼내서 사용
		conditionMap.put("제목", "title");
		conditionMap.put("내용", "content");
		
		return conditionMap;
	}
	
	/*
	 * 게시판 조회
	 */
	@RequestMapping("/getBoardList.do")
	public String getBoardList(BoardVO board, Model model) {
		List<BoardVO> boardList = boardService.getBoardList(board);
		System.out.println("board = " + board);
		System.out.println("boardList = " + boardList);
		model.addAttribute("boardList", boardList);
		System.out.println("게시판 조회 완료 \n");
		
		return "boardList.jsp";
	}
	
	/*
	 * 게시글 조회
	 */
	@RequestMapping("/getBoard.do")
	public String getBoard(BoardVO boardvo, Model model) {
		BoardVO board = boardService.getBoard(boardvo);
		boardService.updateCount(board);
		model.addAttribute("board", board);
		System.out.println("게시글 조회 완료 \n");
		
		return "board.jsp";
	}
	
	/*
	 * 게시글 작성
	 */
	@RequestMapping("/insertBoard.do")
	public String insertBoard(BoardVO board) {
		boardService.insertBoard(board);
		System.out.println("게시글 등록 완료 \n");
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 게시글 수정
	 */
	@RequestMapping("/updateBoard.do")
	public String updateBoard(@ModelAttribute("board") BoardVO board) {
		boardService.updateBoard(board);
		System.out.println("게시글 수정 완료 \n");
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 게시글 삭제
	 */
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(BoardVO board) {
		boardService.deleteBoard(board);
		System.out.println("게시글 삭제 완료 \n");
		
		return "redirect:getBoardList.do";
	}	
	
	/*
	 * 추천수 증가
	 */
	@PostMapping("/recommend.do")
	public String updateRecommendation(BoardVO boardvo, Model model) {
		BoardVO board = boardService.getBoard(boardvo);
		boardService.recommend(board);
		model.addAttribute("board", board);
		System.out.println("추천 완료 \n");
		
		return "board.jsp";
	}

}









