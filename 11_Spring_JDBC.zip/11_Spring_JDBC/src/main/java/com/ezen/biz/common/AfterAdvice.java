package com.ezen.biz.common;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

@Service
@Aspect // 위빙의 역할
public class AfterAdvice {
	// @Pointcut("execution(* com.ezen.biz..*Impl.*(..))") // 포인트컷 생성
	// public void allPointCut() {}
	
	@After("PointCutCommon.allPointCut()") // 포인트컷 지정
	public void finallyLog() {
		System.out.println("[사후 처리] 비즈니스 로직 수행 후 무조건 동작");
	}
}
