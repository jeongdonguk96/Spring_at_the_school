package com.ezen.biz.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.util.StopWatch;

public class AroundAdvice {
	public Object aroundLog(ProceedingJoinPoint pjp) throws Throwable {
		// 1. jp의 이름을 method에 저장
		String method = pjp.getSignature().getName();

		// 2. jp의 실행시간 측정을 위해 StopWatch() 객체 생성
		StopWatch stopWatch = new StopWatch();
		
		// 3. 비즈니스 매서드 시작시간 측정
		stopWatch.start();
				
		// 4. jp 실행 결과 returnObj에 저장
		Object returnObj = pjp.proceed();
		
		// 5. 비즈니스 매서드 종료시간 측정
		stopWatch.stop();
		
		System.out.printf("[AFTER] %s(), 수행에 걸린 시간 : %d(ms) \n", method, stopWatch.getTotalTimeMillis());
		
		return returnObj;
	}
}
