package com.ezen.biz.controller;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.ezen.biz.board.BoardService;
import com.ezen.biz.dto.BoardVO;

@Controller
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	/*
	 * 글 등록 기능
	 */
	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO board, HttpSession session) throws IllegalStateException, IOException {
		
		// 파일 업로드 처리
		MultipartFile uploadFile = board.getUploadFile();
		
		String realPath = session.getServletContext().getRealPath("/images/");
		
		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			//System.out.println("fileName="+fileName);
			fileName = uniqueFileName(fileName);
			board.setFileName(fileName);
			uploadFile.transferTo(new File(realPath+fileName));
		}
		
		boardService.insertBoard(board);
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 중복되지 않는 파일명 생성
	 */
	private String uniqueFileName(String originalFileName) {
		// UUID 생성
		UUID uuid = UUID.randomUUID();
		String code = uuid.toString().substring(0, 8);
		String saveFileName = code+"_"+originalFileName;
		System.out.println("uniqueFileName() : "+saveFileName);
		
		return saveFileName;
	}
	
	/*
	 * 글 수정 기능
	 * @ModelAttribute - 세션 내장객체에 저장된 내용이 vo 객체에 저장됨
	 */
	@RequestMapping("/updateBoard.do")
	public String updateBoard(@ModelAttribute("board") BoardVO board, HttpSession session) throws IllegalStateException, IOException {
		
		// 파일 업로드 처리
		MultipartFile uploadFile = board.getUploadFile();
		String realPath = session.getServletContext().getRealPath("/images/");

		if (!uploadFile.isEmpty()) {	// 새로 올린 첨부파일 있음
			String fileName = uploadFile.getOriginalFilename();
			//System.out.println("fileName="+fileName);
			fileName = uniqueFileName(fileName);
			
			if(board.getFileName() != null) {	// 이전에 올린 첨부파일 있음
				File deleteFile = new File(realPath+board.getFileName());
				if(deleteFile.delete()) {
					board.setFileName(fileName);
					uploadFile.transferTo(new File(realPath+fileName));
				} else {
					System.out.println("기존 파일 삭제 실패");
				}
			} else {	// 이전에 올린 첨부파일 없음
				board.setFileName(fileName);
				uploadFile.transferTo(new File(realPath+fileName));
			}
		}
		
		boardService.updateBoard(board);
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 삭제 기능
	 */
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(@ModelAttribute("board") BoardVO board, HttpSession session) {
		
		// 글 삭제시 업로드했던 파일도 삭제
		if(!board.getFileName().isEmpty() || board.getFileName() != null) {
			String realPath = session.getServletContext().getRealPath("/images/");
			
			String path = realPath + board.getFileName();
			
			File file = new File(path);
			if(file.delete()) {
				boardService.deleteBoard(board);
			}
		}
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 상세 조회
	 */
	@RequestMapping("/getBoard.do")
	public String getBoard(BoardVO boardvo, Model model) {
		
		// 게시글 조회수 증가
		boardService.plusReadCnt(boardvo);
		
		BoardVO board = boardService.getBoard(boardvo);
		
		// 응답 화면구성
		
		// @SessionAttributes 사용 시, 
		// model 객체에 저장됨과 동시에 session 내장객체에도 저장됨.
		model.addAttribute("board", board);
		
		return "getBoard.jsp";
	}
	
	/*
	 * 검색조건 목록값을 내장객체에 저장
	 */
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new LinkedHashMap<>();
		
		conditionMap.put("제목", "TITLE");
		conditionMap.put("작성자", "WRITER");
		conditionMap.put("내용", "CONTENT");
		
		return conditionMap;
	}
	
	/*
	 * 글 목록 조회
	 */
	@RequestMapping("/getBoardList.do")
	public String getBoardList(
			//@RequestParam(value="searchCondition", defaultValue="TITLE", required=false) String condition,
			//@RequestParam(value="searchKeyword", defaultValue="", required=false) String keyword,
			BoardVO board,
			Model model) {
		
		if (board.getSearchCondition() == null) board.setSearchCondition("TITLE");
		if (board.getSearchKeyword() == null) board.setSearchKeyword("");
		
		System.out.println("검색 조건: " + board.getSearchCondition());
		System.out.println("검색 키워드: " + board.getSearchKeyword());
		
		// 게시글을 DB에서 조회
		List<BoardVO> boardList = boardService.getBoardList(board);
		
		// 검색결과를 request 객체에 저장하고 jsp 화면 호출
		model.addAttribute("boardList", boardList);
		
		return "getBoardList.jsp";
	}
}
