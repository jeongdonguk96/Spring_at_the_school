package com.ezen.biz.dto;

import java.sql.Date;

import javax.validation.constraints.NotNull;

public class UserVO {
	@NotNull
	private String id;			// user 아이디
	@NotNull
	private String pwd;			// user 비밀번호
	private String name;		// 이름
	private String jumin;		// 주민번호
	private Date regDate;		// 등록일
	private Integer attendance;	// 출석
    private Integer late;		// 지각
    private Integer earlyLeave;	// 조퇴
    private Integer absence;	// 결석
    private String role;		// 권한('user':사용자, 'admin':관리자)
	
	public UserVO() {}
    public UserVO(String id, String pwd, String name, String jumin, Date regDate, Integer attendance, Integer late, Integer earlyLeave, Integer absence, String role) {
        this.id = id;
        this.pwd = pwd;
        this.name = name;
        this.jumin = jumin;
        this.regDate = regDate;
        this.attendance = attendance;
        this.late = late;
        this.earlyLeave = earlyLeave;
        this.absence = absence;
        this.role = role;
    }
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJumin() {
		return jumin;
	}
	public void setJumin(String jumin) {
		this.jumin = jumin;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public Integer getAttendance() {
		return attendance;
	}
	public void setAttendance(Integer attendance) {
		this.attendance = attendance;
	}
	public Integer getLate() {
		return late;
	}
	public void setLate(Integer late) {
		this.late = late;
	}
	public Integer getEarlyLeave() {
		return earlyLeave;
	}
	public void setEarlyLeave(Integer earlyLeave) {
		this.earlyLeave = earlyLeave;
	}
	public Integer getAbsence() {
		return absence;
	}
	public void setAbsence(Integer absence) {
		this.absence = absence;
	}
	@Override
	public String toString() {
		return "UserVO [id=" + id + ", pwd=" + pwd + ", name=" + name + ", jumin=" + jumin
				+ ", regDate=" + regDate + ", role=" + role + "]";
	}
	
	
}
