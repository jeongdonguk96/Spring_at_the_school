package com.ezen.view.controller;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.ezen.biz.board.BoardService;
import com.ezen.biz.dto.BoardVO;

@Controller
@SessionAttributes("board")
public class BoardControllers {
	@Autowired
	private BoardService boardService;
	/*
	 * 검색 조건 목록 생성 - 동적으로 이용하기 위함(model 내장객체에 정보를 담아 .jsp에서 사용)
	 * 여기선 매서드의 리턴값을 "conditionMap"이라는 이름의 model 내장객체에 저장
	 */
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new LinkedHashMap<>();
		
		/*
		 * 이 맵에 put하는 갯수만큼 .jsp에서 forEach로 꺼내서 사용 
		 */
		conditionMap.put("제목", "title");
		conditionMap.put("내용", "content");
		
		return conditionMap;
	}
	
	/*
	 * 글 목록 화면 조회
	 */
	@RequestMapping("/getBoardList.do") // "getBoardList.do" 라는 요청이 있을 때 사용할 매서드로 매핑
	public String getBoardList(
			// @RequestParam(value="searchCondition", defaultValue="title", required=false) String condition,
			// @RequestParam(value="searchKeyword", defaultValue="", required=false) String keyword,
			BoardVO board, Model model) {
		if(board.getSearchCondition() == null) board.setSearchCondition("title"); // 기본값 설정
		if(board.getSearchKeyword() == null) board.setSearchKeyword(""); // 기본값 설정
		
		System.out.println("검색 조건 : " + board.getSearchCondition());
		System.out.println("검색 단어 : " + board.getSearchKeyword());		
		
		// 검색 결과를 model 객체에 저장, 화면 응답 처리
		model.addAttribute("boardList", boardService.getBoardList(board)); // Model에 데이터 정보 저장
		System.out.println("게시판 화면 조회 완료 \n");
	
		return "getBoardList.jsp";
	}
	
	/*
	 * 글 상세 화면 조회
	 */
	@RequestMapping("/getBoard.do")
	public String getBoard(BoardVO board, Model model) {
		// @SessionAttributes 사용 시 model 내장객체에 저장됨과 동시에 session 내장객체에도 저장됨
		model.addAttribute("board", boardService.getBoard(board));
		System.out.println("게시글 상세보기 화면 조회 완료 \n");
		
		return "getBoard.jsp";
	}
	
	/*
	 * 글 등록 처리
	 */
	@RequestMapping("/insertBoard.do")
	public String insertBoard(BoardVO board) throws IOException {
		MultipartFile uploadFile = board.getUploadFile();
		if(!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			System.out.println("fileName = " + fileName);
			uploadFile.transferTo(new File("C:\\Users\\605-03\\Spring_workspace\\upload\\" + fileName));
		}
		
		boardService.insertBoard(board);
		System.out.println("게시글 등록 처리 완료  \n");
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 수정 처리
	 * @ModelAttribute - session 내장객체에 저장된 내용이 BoardVO 객체에 저장
	 */
	@RequestMapping("/updateBoard.do")
	public String updateBoard(@ModelAttribute("board") BoardVO board) {
		System.out.println("작성자 이름 : " + board.getWriter());
		boardService.updateBoard(board);
		System.out.println("게시글 수정 처리 완료 \n");
		
		return "redirect:getBoardList.do";
	}
	
	/*
	 * 글 삭제 처리
	 */
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(BoardVO board) {
		boardService.deleteBoard(board);
		System.out.println("게시글 삭체 처리 완료 \n");
		
		return "redirect:getBoardList.do";
	}
}
