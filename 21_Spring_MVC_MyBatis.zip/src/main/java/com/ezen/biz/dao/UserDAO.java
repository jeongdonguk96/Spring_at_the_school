package com.ezen.biz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.common.JDBCUtil;
import com.ezen.biz.dto.BoardVO;
import com.ezen.biz.dto.UserVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("userDAO")
public class UserDAO {
	
	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 회원 조회
	public UserVO getUser(UserVO user) {
		System.out.println("===> MyBatis로 getUser() 처리");
		   				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		return myBatis.selectOne("userMapper.getUser", user);
	}
}
