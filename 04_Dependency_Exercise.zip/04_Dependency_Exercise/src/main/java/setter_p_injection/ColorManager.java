package setter_p_injection;

public class ColorManager implements Color{
	private Color color;
	
	public ColorManager() {
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
	public void printColor() {
		color.printColor();
	}
}
