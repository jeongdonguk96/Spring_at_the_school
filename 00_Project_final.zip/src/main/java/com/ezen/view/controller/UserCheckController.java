package com.ezen.view.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;
import com.ezen.biz.user.UserCheckService;

@Controller
public class UserCheckController {
	
	@Autowired
	private UserCheckService userCheckService;
	
	/*
	 * 입실등록
	 */
	@PostMapping("/setInTime.do")
	public String setInTime(UserCheckVO user_Check, UserVO user, HttpSession session,
			HttpServletResponse response) throws Exception {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		// '입실'버튼 클릭 시
		UserVO userInfo = (UserVO) session.getAttribute("user");
		if(userInfo != null) {
			user_Check.setId(userInfo.getId());
	        System.out.println("attendId = " + userInfo.getId());
	
			/* 오늘 입실시간 조회 */
	        UserCheckVO entrance = userCheckService.readCheckIn(user_Check.getId());
	        if(entrance != null) {	// 오늘 입실시간이 있으면
		        
	        	out.print("<script language='javascript'>alert('이미 입실하셨습니다.')</script>");
	        	out.flush();
	        	System.out.println("이미 입실하셨습니다."); 
	
	        } else {	// 오늘 입실 시간이 없으면
	        	userCheckService.checkIn(user_Check);
	        	entrance = userCheckService.readCheckIn(user_Check.getId());
				session.setAttribute("userEntry", entrance);
				out.print("<script language='javascript'>alert('입실했습니다.')</script>");
				out.flush();				
				System.out.println("입실등록 처리 성공 \n");
	        }
			return "main.jsp";
		} else {
			return "login.jsp";
		}
	}
	
	/*
	 * 퇴실등록
	 */
	@PostMapping("/setOutTime.do")
	public String setOutTime(UserCheckVO user_Check, UserVO user, HttpSession session,
			HttpServletResponse response) throws Exception {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		// '퇴실'버튼 클릭 시

		/* 오늘 퇴실시간 조회 */
		UserCheckVO leave = userCheckService.readCheckOut(user_Check.getId());
		if(leave != null) {	// 오늘 퇴실 기록이 있으면
			
			out.print("<script language='javascript'>alert('이미 퇴실하셨습니다.')</script>");
			out.flush();
			System.out.println("이미 퇴실하셨습니다.");

		} else {	// 오늘 퇴실 기록이 없으면
			userCheckService.checkOut(user_Check);
			leave = userCheckService.readCheckOut(user_Check.getId());
	        
			session.setAttribute("userOut", leave);
			out.print("<script language='javascript'>alert('퇴실했습니다.')</script>");
			out.flush();				
			System.out.println("퇴실등록 처리 성공 \n");
		}

		return "main.jsp";
	}
	
}
