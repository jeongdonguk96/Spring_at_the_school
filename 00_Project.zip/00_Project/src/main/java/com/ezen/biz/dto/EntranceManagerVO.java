package com.ezen.biz.dto;

import java.sql.Timestamp;

public class EntranceManagerVO {
	private Timestamp entranceTime;

	public Timestamp getEntranceTime() {
		return entranceTime;
	}
	public void setEntranceTime(Timestamp entranceTime) {
		this.entranceTime = entranceTime;
	}

	@Override
	public String toString() {
		return "EntranceManager [entranceTime=" + entranceTime + "]";
	}
}
