package polymorphism;

public class TVUser {

	public static void main(String[] args) {
//		TV tv = new SamsungTV();
		TV tv = new LgTv();
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();

	}

}
