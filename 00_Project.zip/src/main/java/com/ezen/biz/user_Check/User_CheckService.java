package com.ezen.biz.user_Check;

import com.ezen.biz.dto.User_CheckVO;

public interface User_CheckService {
	void setInTime(User_CheckVO user_Check);
	
	void setOutTime(User_CheckVO user_Check);

	void updateInTime(User_CheckVO user_Check);
	
	void updateOutTime(User_CheckVO user_Check);
	
	User_CheckVO getLatestInTime(User_CheckVO user_Check);
	
	User_CheckVO getLatestOutTime(User_CheckVO user_Check);
	
	
}
