package com.ezen.biz.SystemManager;

import com.ezen.biz.dto.EntranceManagerVO;

public interface EntranceManagerService {
	void registerEntranceTime(EntranceManagerVO entranceManager);
}
