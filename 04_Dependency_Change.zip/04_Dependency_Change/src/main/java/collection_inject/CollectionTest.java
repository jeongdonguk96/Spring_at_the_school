package collection_inject;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CollectionTest {
	
	public static void main(String[] args) {
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		CollectionBean bean = (CollectionBean) factory.getBean("collectionBean");
		
		/*
		 * addressList는 String타입의 list컬렉션
		 */
		List<String> addressList = bean.getAddressList();
		
		for(String address : addressList) {
			System.out.println("address = " + address);
		}
		
		/*
		 * bookList는 참조타입의 list컬렉션
		 */
		List<Book> bookList = bean.getBookList();
		
		for(Book book : bookList) {
			System.out.println("book = " + book);
		}
		
		/*
		 * movieList는 String타입의 set컬렉션
		 */
		Set<String> movieList = bean.getMovieList();
		
		for(String movie : movieList) {
			System.out.println("movie = " + movie);
		}
		
		/*
		 * map은 키와 밸류가 String타입의 map컬렉션
		 */
		Map<String, String> map = bean.getPrefList();
		Set<String> keys = map.keySet(); // 모든 키의 정보를 읽어옴
		
		for(String key : keys) {
			System.out.println("map = " + key + ", " + map.get(key));
		}
		
		/*
		 * propList는 키와 밸류가 String타입의 Properties컬렉션
		 */
		Properties propList = bean.getPropList();
		Set<String> items = (Set) propList.keySet();
		
		for(String item : items) {
			System.out.println("property = " + item + ": " + propList.get(item));
		}
		
		factory.close();
	}
}
