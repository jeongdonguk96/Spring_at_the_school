package com.ezen.biz.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ezen.biz.dto.BoardVO;
import com.ezen.biz.util.SqlSessionFactoryBean;

public class BoardDAO {
	private SqlSession mybatis; // DB와 연결하는 객체
	
	public BoardDAO() {
		mybatis = SqlSessionFactoryBean.getSqlSessionInstance();
	}
	
	// 글 등록 매서드
	public void insertBoard(BoardVO board) {
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		mybatis.insert("boardMapper.insertBoard", board);
		mybatis.commit();
	}
	
	// 글 수정 매서드
	public void updateBoard(BoardVO board) {
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		mybatis.insert("boardMapper.updateBoard", board);
		mybatis.commit();
	}
	
	// 글 삭제 매서드
	public void deleteBoard(BoardVO board) {
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		mybatis.insert("boardMapper.deleteBoard", board);
		mybatis.commit();
	}
	
	// 글 전체 조회 매서드
	public List<BoardVO> getBoardList(BoardVO board) {
							  // ("실행될 sql문의 id", returnType으로 지정된 객체)
		return mybatis.selectList("boardMapper.getBoardList", board);
	}
	
	// 글 상세 조회 매서드
	public BoardVO getBoard(BoardVO board) {
		  					 // ("실행될 sql문의 id", returnType으로 지정된 객체)
		return mybatis.selectOne("boardMapper.getBoard", board);
	}
}















