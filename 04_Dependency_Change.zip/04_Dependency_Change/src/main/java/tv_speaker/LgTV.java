package tv_speaker;

public class LgTV implements TV {

	private Speaker speaker;
	private int price;
	
	public LgTV() {}
	
	public LgTV(Speaker speaker) {
		this.speaker = speaker;
	}

	public LgTV(Speaker speaker, int price) {
		this.speaker = speaker;
		this.price = price;
	}

	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public void powerOn() {
		System.out.println("LgTV -- 전원을 켭니다");
		System.out.println("price = " + price);
	}

	@Override
	public void powerOff() {
		System.out.println("LgTV -- 전원을 끕니다");
	}

	@Override
	public void volumeUp() {
		speaker.volumeUp();
	}

	@Override
	public void volumeDown() {
		speaker.volumeDown();
	}

}
