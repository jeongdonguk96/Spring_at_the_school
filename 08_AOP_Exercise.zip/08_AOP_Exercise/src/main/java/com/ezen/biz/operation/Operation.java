package com.ezen.biz.operation;

public interface Operation {

	void message();

	int m();

	int k();

	void throwException();

}