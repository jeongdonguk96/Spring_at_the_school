package com.ezen.biz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.biz.SystemManager.LeavingManagerService;
import com.ezen.biz.dto.LeavingManagerVO;

@Controller
public class LeavingManagerController {
	
	@Autowired
	private LeavingManagerService leavingManagerService;
	
	/*
	 * 퇴실등록
	 */
	@RequestMapping("/registerLeavingTime.do")
	public String registerLeavingTime(LeavingManagerVO leavingManager) {
		leavingManagerService.registerLeavingTime(leavingManager);
		
		return "redirect:getMainPage.do";
	}
}
