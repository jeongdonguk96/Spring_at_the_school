package com.ezen.biz.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.biz.dto.UserVO;
import com.ezen.biz.user.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	/*
	 * 로그인 화면 조회
	 * GetMapping으로 처리 -> 세션없을 시 로그인 화면으로
	 */
	@GetMapping("/login.do")
	public String loginView(UserVO user) {
		
		return "login.jsp";
	}
	
	/*
	 * 로그인
	 * PostMapping으로 처리 -> 세션있으면 로그인 절차 후 메인 화면으로
	 */
	@PostMapping("/login.do")
	public String login(UserVO uservo, HttpSession session) {
		UserVO user = userService.getUser(uservo);
		System.out.println("uservo = " + uservo);
		System.out.println("user = " + user);
		if(user != null) { // 로그인 성공 시
			session.setAttribute("user", user);
			System.out.println("로그인 처리 완료 \n");
			
			return "main.jsp";
		} else {
			System.out.println("로그인 처리 실패 \n");
			
			return "login.jsp";
		}
	}
	
	/*
	 * 로그아웃
	 */
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "main.jsp";
	}
	
	/*
	 * 회원가입
	 */
	@PostMapping("/join.do")
	public String join(UserVO user) {
		System.out.println(user);
		userService.insertUser(user);
		System.out.println("회원가입 처리 완료 \n");
		
		return "main.jsp";
	}
	
	/*
	 * 회원정보 수정
	 */
	@RequestMapping("/update.do")
	public String updateUser(UserVO user, HttpSession session) {
		userService.updateUser(user);
		session.setAttribute("user", user);
		System.out.println("회원정보 수정 처리 완료 \n");
		
		return "main.jsp";
	}
	
	/*
	 * 아이디 수정
	 */
	@RequestMapping("/updateId.do")
	public String updateId(UserVO user, HttpSession session) {
		userService.updateId(user);
		session.setAttribute("user", user);
		System.out.println("아이디 수정 처리 완료 \n");
		
		return "main.jsp";
	}
	
	/*
	 * 비밀번호 수정
	 */
	@RequestMapping("/updatePwd.do")
	public String updatePwd(UserVO user, HttpSession session) {
		userService.updatePwd(user);
		session.setAttribute("user", user);
		System.out.println("비밀번호 수정 처리 완료 \n");
		
		return "main.jsp";
	}
	
	/*
	 * 회원탈퇴
	 */
	@RequestMapping("/delete.do")
	public String deleteUser(UserVO user) {
		userService.deleteUser(user);
		System.out.println("회원탈퇴 처리 완료 \n");
		
		return "main.jsp";
	}
}



