package com.ezen.view.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserVO;

@Controller
public class UserControllers {
	/*
	 * 로그인 화면 조회
	 */
	@GetMapping("/login.do")
	public ModelAndView loginView(@ModelAttribute("user") UserVO user, ModelAndView modelView) {
		user.setId("user1"); // 테스트 편의 위해
		user.setPwd("user1"); // 테스트 편의 위해
		modelView.setViewName("login.jsp");
		System.out.println("로그인 화면 조회 완료 \n");
		
		return modelView;
	}
	
	/*
	 * 로그인 처리
	 */
	@PostMapping("/login.do")
	public ModelAndView login(UserVO uservo, UserDAO userDAO, ModelAndView modelView) {
		UserVO user = userDAO.getUser(uservo);
		if(user != null) { // 로그인 성공 시
			modelView.setViewName("redirect:getBoardList.do"); // jsp화면이 아닐 시 redirect:를 붙여줘야 함
			System.out.println("로그인 처리 완료 \n");
			
			return modelView;
		} else { 		  					// 로그인 실패 시
			modelView.setViewName("login.jsp");
			System.out.println("로그인 처리 실패 \n");
			
			return modelView;
		}
	}
	
	/*
	 * 로그아웃 처리
	 */
	@RequestMapping("/logout.do")
	public ModelAndView logout(ModelAndView modelView, HttpSession session) {		
		session.invalidate();
		modelView.setViewName("login.jsp"); // View에 정보 저장
		System.out.println("로그아웃 처리 완료 \n");
		
		return modelView;
	}	
}
