package com.ezen.biz.board;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.ezen.biz.dto.BoardVO;

public class BoardServiceClient {

	public static void main(String[] args) {
		// 1. 스프링 컨테이너 구동
		AbstractApplicationContext container = new GenericXmlApplicationContext("applicationContext.xml");
		
		// 2. 스프링 컨테이너에 필요한 객체 요청(Lookup)
		BoardService boardService = (BoardService) container.getBean("boardService");
							   // = new BoardService() 와 같은 의미이지만 다른 점은 스프링에서 DI를 받는 형식이라는 것
		
		// 3. 글 등록
		for(int i=1; i<=3; i++) {
			BoardVO board = new BoardVO();
			board.setTitle("게시글 제목" + i);
			board.setWriter("작성자" + i);
			board.setContent(i + "번 스프링 예제 게시글입니다.");
			boardService.insertBoard(board);
		}
		
		// 4. 글 목록 조회
		List<BoardVO> boardList = boardService.getBoardList();
		
		for(BoardVO board : boardList) {
			System.out.println(board);
		}
		
		// 5. 컨테이너 종료
		container.close();
	}

}
