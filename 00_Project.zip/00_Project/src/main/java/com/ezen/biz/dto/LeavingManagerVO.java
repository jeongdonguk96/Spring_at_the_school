package com.ezen.biz.dto;

import java.sql.Timestamp;

public class LeavingManagerVO {
	private Timestamp leavingTime;

	public Timestamp getleavingTime() {
		return leavingTime;
	}
	public void setleavingTime(Timestamp leavingTime) {
		this.leavingTime = leavingTime;
	}

	@Override
	public String toString() {
		return "leavingManager [leavingTime=" + leavingTime + "]";
	}
}
