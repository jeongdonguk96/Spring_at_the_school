package com.ezen.biz.common;

/*
 * 비즈니스 매서드에 적용할 로깅처리 클래스
 */
public class BeforeAdvice {
	public void beforeLog() {
		System.out.println("[사전 처리] 비즈니스 로직 수행 전 작업");
	}
}
