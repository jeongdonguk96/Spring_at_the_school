package com.ezen.biz.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserVO;
import com.ezen.biz.user.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	
	/*
	 * 로그인
	 */
	@PostMapping("/login.do")
	public String login(@Valid UserVO uservo, UserDAO userDAO, HttpSession session) {
		UserVO user = userService.login(uservo);
		
		if(user != null) { // 로그인 성공 시
			if(user.getRole().equals("admin")) { // 권한이 관리자일 시
				return "redirect:getAdminPage.do";
			}
			session.setAttribute("userName", user.getName());
			System.out.println("로그인 처리 완료 \n");
			return "redirect:getMainPage.do";
		} else { 		   // 로그인 실패 시
			System.out.println("로그인 처리 실패 \n");
			return "login.jsp";
		}
	}
	
	/*
	 * 로그아웃
	 */
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "login.jsp";
	}
	
	/*
	 * 회원가입
	 */
	@PostMapping("/join.do")
	public String join(UserVO user) {
		userService.insertUser(user);
		
		return "redirect:getMainPage.do";
	}
	
	/*
	 * 회원정보 수정
	 */
	@PostMapping("/updateUser.do")
	public String updateUser(UserVO user) {
		userService.updateUser(user);
		
		return "redirect:getMainPage.do";
	}
	
	/*
	 * 회원탈퇴
	 */
	@PostMapping("/deleteUser.do")
	public String deleteUser(UserVO user, HttpSession session) {
		userService.deleteUser(user);
		
		session.invalidate();
		return "login.jsp";
	}
}





