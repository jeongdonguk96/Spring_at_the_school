package com.ezen.biz.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.ezen.biz.dto.EquipmentVO;

@Service("equipmentDAO")
public class EquipmentDAO {
	
	/*
	 * DB와 연동을 해줄 스프링JDBC 객체 생성 (스프링 컨테이너에 셋팅)
	 */
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/*
	 * 조회할 때 사용하는 RowMapper 인터페이스를 구현한 클래스
	 * 조회하는 작업을 따로 클래스로 떼내어 모듈화해서 사용하는 방식
	 */
	class EquipmentRowMapper implements RowMapper<EquipmentVO> {
		@Override
		public EquipmentVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			EquipmentVO equipment = new EquipmentVO();
			
			equipment.setEquipment_id(rs.getString("equipment_id"));
			equipment.setRoom_id(rs.getString("room_id"));
			equipment.setEquipment_name(rs.getString("equipment_name"));
			equipment.setEquipment_count(rs.getInt("equipment_count"));
			equipment.setEquipment_remarks(rs.getString("equipment_remarks"));
			
			return equipment;
		}	
	}
	
	/*
	 * SQL문은 상수 final
	 */
	private static final String GET_EQUIPMENT_INFO = "SELECT * FROM equipment WHERE room_id=?";
	private static final String INSERT_EQUIPMENT = "INSERT INTO equipment VALUES(?, ?, ?, ?, ?)";
	private static final String UPDATE_EQUIPMENT = "UPDATE equipment SET(equipment_id=?, room_id=?, equipment_name=?, equipment_count=?, equipment_remarks=?) WHERE equipment_id=?";
	private static final String DELETE_EQUIPMENT = "DELETE FROM equipment WHERE equipment_id=?";
	
	// 회의실 번호를 조건으로 회의실의 시설 조회
	public List<EquipmentVO> getEquipmentById(String roomId) {
		Object[] args = {roomId};
		
		return jdbcTemplate.query(GET_EQUIPMENT_INFO, args, new EquipmentRowMapper()); 
	}
	
	// 회의실에 시설을 추가
	public void insertEquipment(EquipmentVO equip) {
		Object[] args = {equip.getEquipment_id(), equip.getRoom_id(), equip.getEquipment_name(), equip.getEquipment_count(), equip.getEquipment_remarks()}; 
		
		jdbcTemplate.update(INSERT_EQUIPMENT, args);
	}
	
	// 회의실 번호를 조건으로 회의실 시설을 수정
	public int updateEquipmentById(EquipmentVO equip) {
		Object[] args = {equip.getEquipment_id(), equip.getRoom_id(), equip.getEquipment_name(), equip.getEquipment_count(), equip.getEquipment_remarks(), equip.getEquipment_id()}; 
		
		return jdbcTemplate.update(UPDATE_EQUIPMENT, args);
	}
	
	// 회의실 번호를 조건으로 회의실 시설을 삭제
	public int deleteEquipmentById(EquipmentVO equip) {
		
		return jdbcTemplate.update(DELETE_EQUIPMENT, equip.getEquipment_id());
	}
}
