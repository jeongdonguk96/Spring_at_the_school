package com.ezen.biz.room;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.ezen.biz.dto.EquipmentVO;
import com.ezen.biz.dto.RoomVO;

public class RoomServiceClient {

	private static RoomService roomService = null;
	
	public static void main(String[] args) {
		// 1. 스프링 컨테이너 구동
		AbstractApplicationContext container = new GenericXmlApplicationContext("applicationContext.xml");
		
		// 2. 스프링 컨테이너에 필요한 객체 요청(Lookup)
		roomService = (RoomService) container.getBean("roomService");
		
		// 3. SQL 결과물 출력
		RoomVO room = new RoomVO();

		/*
		 * 새로운 room과 그곳의 equipment 추가 - 아래에 매서드 있음 
		 */
//		addRoomAndEquipment();
		
		/*
		 * 전체 room 조회 - 아래에 매서드 있음
		 */
		printAllRoomInfo();
		
		/*
		 * 특정 room 조회 - 아래에 매서드 있음
		 */
		room = roomService.getRoomById("D001");
		printRoomInfo(room);
		
		container.close();
	}
	
	/*
	 * 특정 room 조회하는 매서드
	 */
	public static void printRoomInfo(RoomVO room) {
		System.out.println("\n >>> 회의실 정보");
		System.out.println(room);
		System.out.println("\t>>> 부대시설 정보");
		
		if(room.getEquipmentList() != null) {
			List<EquipmentVO> equipmentLists = room.getEquipmentList();
			
			for(EquipmentVO equipmentList : equipmentLists) {
				System.out.println(equipmentList);
			}
		}
	}
	
	/*
	 * 전체 room 조회하는 매서드
	 */
	public static void printAllRoomInfo() {
		List<RoomVO> AllRoomList = roomService.getAllRoom();
		
		System.out.println(">>> 모든 회의실 정보");
		
		for(RoomVO roomList : AllRoomList) {
			System.out.println(roomList);
		}
	}
	
	/*
	 * 새로운 room과 equipment를 각자 테이블에 추가하는 매서드
	 */
	public static void addRoomAndEquipment() {
		// 새로운 room 추가
		RoomVO room1 = new RoomVO();
		List<EquipmentVO> equipmentList = new ArrayList<>();
		room1.setRoom_id("D001");
		room1.setRoom_name("게스트룸");
		room1.setCapacity(10);
		
		// 새로운 equipment1 추가
		EquipmentVO equipment1 = new EquipmentVO();
		
		equipment1.setEquipment_id("77-5");
		equipment1.setRoom_id("D001");
		equipment1.setEquipment_name("회의용 테이블");
		equipment1.setEquipment_count(1);
		equipment1.setEquipment_remarks("10인용 테이블");
		
		equipmentList.add(equipment1);
		
		// 새로운 equipment2 추가
		EquipmentVO equipment2 = new EquipmentVO();
		
		equipment2.setEquipment_id("88-1");
		equipment2.setRoom_id("D001");
		equipment2.setEquipment_name("회의용 테이블");
		equipment2.setEquipment_count(1);
		equipment2.setEquipment_remarks("10인용 테이블");
		
		equipmentList.add(equipment2);
		
		// room에 equipmentList 저장
		room1.setEquipmentList(equipmentList);
		
		// insertRoom() 매서드 실행
		roomService.insertRoom(room1);
	}
}
