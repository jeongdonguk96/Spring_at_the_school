package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.BoardVO;

@Repository("boardDAO")
public class BoardDAO {
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 게시판 조회
	public List<BoardVO> getBoardList(BoardVO board) {
		System.out.println("===> MyBatis로 getBoardList() 처리");
		
		return myBatis.selectList("boardMapper.getBoardList", board);
	}
	
	// 게시글 조회
	public BoardVO getBoard(BoardVO board) {
		System.out.println("===> MyBatis로 getBoard() 처리");		
		
		return myBatis.selectOne("boardMapper.getBoard", board);
	}
	
	// 게시글 작성
	public void insertBoard(BoardVO board) {
		System.out.println("===> MyBatis로 insertBoard() 처리");	
		
		myBatis.insert("boardMapper.insertBoard", board);
	}
	
	// 게시글 수정
	public void updateBoard(BoardVO board) {
		System.out.println("===> MyBatis로 updateBoard() 처리");
		
		myBatis.update("boardMapper.updateBoard", board);
	}
	
	// 게시글 삭제
	public void deleteBoard(BoardVO board) {
		System.out.println("===> MyBatis로 deleteBoard() 처리");		
		
		myBatis.delete("boardMapper.deleteBoard", board);
	}
}
