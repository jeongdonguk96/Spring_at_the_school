package com.ezen.biz.user_Check;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.User_CheckDAO;
import com.ezen.biz.dto.User_CheckVO;

@Service("user_CheckService")
public class User_CheckServiceImpl implements User_CheckService {
	
	@Autowired
	private User_CheckDAO user_CheckDAO;
	
	@Override
	public void setInTime(User_CheckVO user_Check) {
		user_CheckDAO.setInTime(user_Check);
	}

	@Override
	public void updateInTime(User_CheckVO user_Check) {
		user_CheckDAO.updateInTime(user_Check);
	}
	
	@Override
	public void setOutTime(User_CheckVO user_Check) {
		user_CheckDAO.setOutTime(user_Check);
	}
	
	@Override
	public void updateOutTime(User_CheckVO user_Check) {
		user_CheckDAO.updateOutTime(user_Check);
	}

	@Override
	public User_CheckVO getLatestInTime(User_CheckVO user_Check) {
		return user_CheckDAO.getLatestInTime(user_Check);
	}

	@Override
	public User_CheckVO getLatestOutTime(User_CheckVO user_Check) {
		return user_CheckDAO.getLatestOutTime(user_Check);
	}
}
