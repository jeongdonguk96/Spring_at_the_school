package exercise;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {
		AbstractApplicationContext factory =
				new GenericXmlApplicationContext("applicationContext.xml");
		
		InventoryService svc = (InventoryService)factory.getBean("inventory");
		
		svc.testInventoryService();
		
		factory.close();
	}
}
