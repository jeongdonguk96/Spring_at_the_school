package com.ezen.biz.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.UserCheckVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("userCheckDAO")
public class UserCheckDAO {
	
	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;

	// 입실 등록
	public int insertInTime(UserCheckVO user_Check) throws Exception {
		return myBatis.insert("attendMapper.insertInTime", user_Check);
	}

	// 퇴실 등록(user_check table update)
	public int updateCheckOut(UserCheckVO user_Check) throws Exception {
		return myBatis.update("attendMapper.updateCheckOut",user_Check);
	}

	// 오늘 입실정보 조회
	public UserCheckVO selectInTime(String id) throws Exception {
		return myBatis.selectOne("attendMapper.selectInTime",id);
	}

	// 오늘 퇴실정보 조회
	public UserCheckVO selectOutTime(String id) throws Exception {
		return myBatis.selectOne("attendMapper.selectOutTime",id);
	}

	// 오늘 날짜에 출석한 사람 조회(오늘 퇴실까지 찍어야 함)
	public List<UserCheckVO> selectTodayList() throws Exception {
		return myBatis.selectList("attendMapper.selectTodayList");
	}

	// 전체 출결정보 조회(입실, 퇴실)
	public List<UserCheckVO> selectAllDayList() throws Exception {
		return myBatis.selectList("attendMapper.selectAllDayList");
	}
}
