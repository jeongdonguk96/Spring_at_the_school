package com.ezen.biz;

import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dto.BoardVO;

public class BoardServiceClient {

	public static void main(String[] args) {
		BoardVO board = new BoardVO();
		BoardDAO boardDAO = new BoardDAO();
		
		board.setTitle("매이배테싀");
		board.setWriter("뭰세");
		board.setContent("helle, everebede");
		
		boardDAO.insertBoard(board);
	}

}
