package com.ezen.biz.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.UserVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("userDAO")
public class UserDAO {

	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 로그인
	public UserVO login(UserVO user) {
		System.out.println("===> MyBatis로 login() 처리");
		   			// ("실행될 sql문의 id", resultType으로 지정된 객체)
		return myBatis.selectOne("userMapper.login", user);
	}
	
	// 로그아웃
	public void logout() {
		System.out.println("===> logout() 처리");

	}
	
	// 회원가입
	public void joinUser(UserVO user) {
		System.out.println("===> MyBatis로 join() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.insert("userMapper.join", user);
	}
	
	// 회원정보 수정
	public void updateUser(UserVO user) {
		System.out.println("===> MyBatis로 updateUser() 처리");
				// ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.update("userMapper.updateUser", user);
	}
	
	// 회원탈퇴
	public void deleteUser(UserVO user) {
		System.out.println("===> MyBatis로 deleteUser() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.delete("userMapper.deleteUser", user);
	}
		
	// 회원 출결정보 조회
	public UserVO getUserInfo(UserVO user) {
		System.out.println("===> MyBatis로 getUserInfo() 처리");
		
		return myBatis.selectOne("userMapper.getUserInfo", user);
	}
}
