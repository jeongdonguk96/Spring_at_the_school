package com.ezen.biz.util;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/*
 * sql-map-config.xml을 읽어 sql 세션을 만드는 클래스
 */
public class SqlSessionFactoryBean {
	private static SqlSessionFactory sessionFactory = null;
	
	static {
		if(sessionFactory == null) {
			try {

				Reader reader = Resources.getResourceAsReader("sql-map-config.xml"); // 설정 정보를 읽기 위한 입력 스트림 생성
				sessionFactory = new SqlSessionFactoryBuilder().build(reader); // 입력 스트림을 통해 설정 정보를 읽어 SqlSessionFactory 객체 생성
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * 위에서 생성한 DB 연결세션을 다른 매서드에 제공
	 */
	public static SqlSession getSqlSessionInstance() {
		return sessionFactory.openSession(); // SqlSessionFactory 객체로부터 SqlSession을 얻어와 연결 객체를 반환 
	}
}
