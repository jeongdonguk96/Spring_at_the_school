package com.ezen.biz.common;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class PointCutCommon {
	@Pointcut("execution(* com.ezen.biz..*Impl.*(..))") // 포인트컷 생성
	public void allPointCut() {}
	
	@Pointcut("execution(* com.ezen.biz..*Impl.get*(..))") // 포인트컷 생성
	public void getPointCut() {}
}
