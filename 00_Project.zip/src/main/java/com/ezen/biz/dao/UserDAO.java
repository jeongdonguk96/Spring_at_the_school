package com.ezen.biz.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import com.ezen.biz.dto.UserVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
public class UserDAO {

	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 회원가입
	public void insertUser(UserVO user) {
		System.out.println("===> MyBatis로 insertUser() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		myBatis.insert("userMapper.insertUser", user);
	}
}
