package com.ezen.biz.operation;

import org.springframework.stereotype.Service;

@Service("operation")
public class OperationImpl implements Operation {
	@Override
	public void message() {
		System.out.println("message() 매서드 호출됨");
	}
	
	@Override
	public int m() {
		System.out.println("m() 매서드 호출됨");
		return 2;
	}
	
	@Override
	public int k() {
		System.out.println("k() 매서드 호출됨");
		return 3;
	}
	
	@Override
	public void throwException() {
		throw new RuntimeException("예외 발생...");
	}
}
