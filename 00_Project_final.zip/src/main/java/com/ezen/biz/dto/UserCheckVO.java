package com.ezen.biz.dto;

import java.sql.Timestamp;

public class UserCheckVO {
	private String seq;			// 시퀀스
	private String id;			// user id
	private Timestamp inTime;	// 입실 일시
	private Timestamp outTime;	// 퇴실 일시
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Timestamp getInTime() {
		return inTime;
	}
	public void setInTime(Timestamp inTime) {
		this.inTime = inTime;
	}
	public Timestamp getOutTime() {
		return outTime;
	}
	public void setOutTime(Timestamp outTime) {
		this.outTime = outTime;
	}
	
	@Override
	public String toString() {
		return "UserCheckVO [seq=" + seq + ", id=" + id + ", inTime=" + inTime + ", outTime=" + outTime + "]";
	}
	
}
