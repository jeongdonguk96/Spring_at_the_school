package com.ezen.biz.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserVO;

@Service("userService")
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDAO userDAO;
	
	// 로그인
	@Override
	public UserVO getUser(UserVO user) {
		return userDAO.getUser(user);
	}
	// 회원가입
	@Override
	public void insertUser(UserVO user) {
		userDAO.insertUser(user);
	}

	// 회원정보 수정
	@Override
	public void updateUser(UserVO user) {
		userDAO.updateUser(user);
	}

	// 아이디 수정
	@Override
	public void updateId(UserVO user) {
		userDAO.updateId(user);
	}

	// 비밀번호 수정
	@Override
	public void updatePwd(UserVO user) {
		userDAO.updatePwd(user);
	}

	// 회원탈퇴
	@Override
	public void deleteUser(UserVO user) {
		userDAO.deleteUser(user);
	}



}
