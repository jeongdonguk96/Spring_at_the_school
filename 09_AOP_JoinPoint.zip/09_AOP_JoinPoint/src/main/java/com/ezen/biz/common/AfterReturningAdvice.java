package com.ezen.biz.common;

import org.aspectj.lang.JoinPoint;

public class AfterReturningAdvice {
	public void afterLog(JoinPoint jp, Object returnObj) { // returnObj는 join point 실행 후 리턴값을 의미
														   // xml파일에 별도로 returning="returnObj" 지정 (리턴 값을 returnObj에 담겠다는 의미)
		String method = jp.getSignature().getName(); // join point의 정보를 가져와서 그 중에 매서드 이름을 가져옴
		
		System.out.println("[사후 처리] 비즈니스 로직 수행 후 작업");
		System.out.printf("[사후 처리] 매서드명: %s, 리턴값: %s \n", method, returnObj.toString());
	}
}
