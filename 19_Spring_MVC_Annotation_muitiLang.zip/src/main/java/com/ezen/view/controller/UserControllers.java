package com.ezen.view.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserVO;

@Controller
public class UserControllers {
	/*
	 * 로그인 화면 조회
	 * 여기선 UserVO 객체를 "user"라는 이름의 model 내장객체에 저장
	 * @GetMapping으로 매핑, login.do로 매핑하지만 id와 pwd 미기입 상황이라 get으로 처리
	 */
	@GetMapping("/login.do")
	public String loginView(@ModelAttribute("user") UserVO user) {
		user.setId("user1"); // 테스트 편의 위해
		user.setPwd("user1"); // 테스트 편의 위해
		System.out.println("로그인 화면 조회 완료 \n");
		
		return "login.jsp";
	}
	
	/*
	 * 로그인 처리
	 * @PostMapping으로 매핑, login.do로 매핑하지만 위와 다르게 id와 pwd 기입시 로그인 처리하는 기능
	 */
	@PostMapping("/login.do")
	public String login(UserVO uservo, UserDAO userDAO, HttpSession session) {
		if(uservo.getId().equals("") || uservo.getPwd().equals("")) {
			throw new IllegalArgumentException("아이디와 패스워드는 반드시 입력해야 합니다.");
		}
				
		UserVO user = userDAO.getUser(uservo);
		if(user != null) { // 로그인 성공 시
			session.setAttribute("userName", user.getName());
			System.out.println("로그인 처리 완료 \n");
			
			return "redirect:getBoardList.do"; // jsp화면이 아닐 시 redirect:를 붙여줘야 함
		} else { 		   // 로그인 실패 시
			System.out.println("로그인 처리 실패 \n");
			
			return "login.jsp";
		}
	}
	
	/*
	 * 로그아웃 처리
	 */
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {		
		session.invalidate();
		System.out.println("로그아웃 처리 완료 \n");
		
		return "login.jsp";
	}	
}
