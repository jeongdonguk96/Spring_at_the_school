package com.ezen.biz.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.EntranceManagerVO;
import com.ezen.biz.dto.LeavingManagerVO;

/*
 * bean파일에 SqlSessionTemplate를 등록해 MyBatis 구현하는 방법
 */
@Repository("leavingManagerDAO")
public class LeavingManagerDAO {
	
	// applicationContext.xml에 등록한 SqlSessionTemplate을 사용
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 퇴실시간 저장
	public void registerLeavingTime(LeavingManagerVO leaving) {
		myBatis.insert("leavingManagerMapper.registerLeavingTime", leaving);
	}
}
