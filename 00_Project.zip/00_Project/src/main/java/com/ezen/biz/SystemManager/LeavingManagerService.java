package com.ezen.biz.SystemManager;

import com.ezen.biz.dto.LeavingManagerVO;

public interface LeavingManagerService {
	void registerLeavingTime(LeavingManagerVO leavingManager);
}
