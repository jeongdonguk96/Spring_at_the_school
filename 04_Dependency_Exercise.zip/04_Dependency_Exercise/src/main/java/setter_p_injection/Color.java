package setter_p_injection;

public interface Color {
	public void printColor();
}
