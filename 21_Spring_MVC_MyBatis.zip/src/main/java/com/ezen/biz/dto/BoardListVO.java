package com.ezen.biz.dto;

import java.util.List;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/*
 * xml으로 여러 건의 데이터 전달 시 하나의 List 객체로 전달하기 위한 클래스(Root Element) 필요
 * JSON은 자동적으로 list형식으로 반환하지만, xml은 그렇지 않기 때문에 list클래스를 만들어줘야 함 
 */
@XmlRootElement(name="boardList") // 이 클래스 객체가 루트 엘리먼트이고 이름은 "boardList"라는 것을 지정하는 어노테이션
@XmlAccessorType(XmlAccessType.FIELD) // 이 클래스가 xml 파일로 변환될 수 있다는 의미, 멤버변수들은 자식 엘리먼트로 표현됨
public class BoardListVO {
	@XmlElement(name="board") // 이 변수가 엘리먼트이고 이름은 "board"라는 것을 지정하는 어노테이션
	private List<BoardVO> boardList;

	public List<BoardVO> getBoardList() {
		return boardList;
	}

	public void setBoardList(List<BoardVO> boardList) {
		this.boardList = boardList;
	}
}
