package com.ezen.biz.user;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.UserCheckDAO;
import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;

@Service("userCheckService")
public class UserCheckServiceImpl implements UserCheckService {
	
	@Autowired
	private UserCheckDAO userCheckDAO;
	@Autowired
    private UserDAO userDao;
	
	int count = 0;

	@Override
    public int checkIn(UserCheckVO user_Check) throws Exception {
        return userCheckDAO.insertInTime(user_Check);
    }

    @Override
    public int checkOut(UserCheckVO user_Check) throws Exception {
        return userCheckDAO.updateCheckOut(user_Check);
    }

    @Override
    public List<UserVO> attendCommit() throws Exception {
        count = 0;
        List<UserVO> getUser = userDao.selectAllUser();
        System.out.println("getUser = " + getUser);

        for (UserVO getUserId : getUser) {
            System.out.println("getUserId = " + getUserId);
            checkAttend(getUserId.getId());
        }
        return getUser;
    }

    // 출석/지각/조퇴/결석 판별
    @Override
    public int checkAttend(String id) throws Exception {
    	
    	SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
    	Date now = new Date();
    	String today = sf2.format(now);
    	String sTime = today+" 09:40:00";
    	String eTime = today+" 18:00:00";

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date startTime = df.parse(sTime);
        Date endTime = df.parse(eTime);
//        Date startTime = df.parse("2022-12-16 09:40:00");
//        Date endTime = df.parse("2022-12-16 18:00:00");

        System.out.println(" check id =" + id);

        Date inTime = null;
        Date outTime = null;
        try {
            inTime = readCheckIn(id).getInTime();
            outTime = readCheckOut(id).getOutTime();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(" inTime null : 오늘 입실 기록이 없으므로 결석처리 ");
            return countEx(id);
        }

        System.out.println("inTime = " + inTime);
        System.out.println("outTime = " + outTime);

        // ~9시40분 입실 AND 18시~ 퇴실 체크한 경우
        if (inTime.compareTo(startTime) <= 0 && outTime.compareTo(endTime) >= 0) {
            System.out.println("["+id+"] 출석 ");
            return userDao.upAttendance(id);
        }
        // 9시40분~ 입실 AND 18시~ 퇴실 체크한 경우
        if (inTime.compareTo(startTime) > 0 && outTime.compareTo(endTime) >= 0) {
            System.out.println("["+id+"] 지각");
            return userDao.upLate(id);
        }
        // ~9시40분 입실 AND 18시 이전 퇴실 체크한 경우
        if (inTime.compareTo(startTime) <= 0 && outTime.compareTo(endTime) < 0) {
            System.out.println("["+id+"] 조퇴");
            return userDao.upEarlyLeave(id);
        }
        return 0;
    }

    private int countEx(String id) throws Exception {
    	if(count==0) {
    		userDao.upAbsence(id);
    		count++;
    		System.out.println("count = " + count);
    		return count;
    	}
    	return 0;
    }

    @Override
    public UserCheckVO readCheckIn(String id) throws Exception {
        return userCheckDAO.selectInTime(id);
    }

    @Override
    public UserCheckVO readCheckOut(String id) throws Exception {
        return userCheckDAO.selectOutTime(id);
    }

    @Override
    public List<UserCheckVO> getTodayList() throws Exception {
        return userCheckDAO.selectTodayList();
    }

    @Override
    public List<UserCheckVO> getAllDayList() throws Exception {
        return userCheckDAO.selectAllDayList();
    }

}
