package com.ezen.biz.dto;

import java.util.Date;

public class UserVO {
	private String id;
	private String pwd;
	private String name;
	private String jumin;
	private Date ragDate;
	private int attendance;
	private int late;
	private int earlyLeave;
	private int absence;
	private String role;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJumin() {
		return jumin;
	}
	public void setJumin(String jumin) {
		this.jumin = jumin;
	}
	public Date getRagDate() {
		return ragDate;
	}
	public void setRagDate(Date ragDate) {
		this.ragDate = ragDate;
	}
	public int getAttendance() {
		return attendance;
	}
	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}
	public int getLate() {
		return late;
	}
	public void setLate(int late) {
		this.late = late;
	}
	public int getEarlyLeave() {
		return earlyLeave;
	}
	public void setEarlyLeaving(int earlyLeave) {
		this.earlyLeave = earlyLeave;
	}
	public int getAbsence() {
		return absence;
	}
	public void setAbsence(int absence) {
		this.absence = absence;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	@Override
	public String toString() {
		return "UserVO [id=" + id + ", pwd=" + pwd + ", name=" + name + ", jumin=" + jumin + ", ragDate=" + ragDate
				+ ", attendance=" + attendance + ", late=" + late + ", earlyLeave=" + earlyLeave + ", absence="
				+ absence + ", role=" + role + "]";
	}	
}
