package exercise;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("inventory")
public class InventoryService {

	@Autowired
	private InventoryDao inventoryDao;
	
	public void testInventoryService() {
		System.out.println("서비스 클래스, testInventoryService() 입니다.");
		
		inventoryDao.printInventoryDaoStatus();
	}
}
