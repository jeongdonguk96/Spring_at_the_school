package com.ezen.biz.user;

import com.ezen.biz.dto.UserVO;

public interface UserService {
	// 로그인
	UserVO getUser(UserVO user);
	
	// 회원가입
	void insertUser(UserVO user);
	
	// 회원정보 수정
	void updateUser(UserVO user);
	
	// 아이디 수정
	void updateId(UserVO user);
	
	// 비밀번호 수정
	void updatePwd(UserVO user);
	
	// 회원탈퇴
	void deleteUser(UserVO user);
}
