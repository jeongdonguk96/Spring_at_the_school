package com.ezen.biz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import com.ezen.biz.dto.UserVO;
import com.ezen.biz.dto.User_CheckVO;
import com.ezen.biz.user_Check.User_CheckService;


@Controller
public class User_CheckController {
	
	@Autowired
	private User_CheckService user_CheckService;
	
	/*
	 * 입실등록
	 */
	@PostMapping("/setInTime.do")
	public String setInTime(User_CheckVO user_Check, UserVO user, HttpSession session,
			HttpServletResponse response) throws IOException {
		SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
				
		try {
			/*
			 * 최근 등록날짜
			 */
			User_CheckVO entrance = user_CheckService.getLatestInTime(user_Check);
			System.out.println(entrance);
			Date entryTime = entrance.getInTime();
			String latestTime = sf2.format(entryTime);
			String latest = latestTime.substring(8,10);
			System.out.println("entrytime = " + entryTime);
			System.out.println("latestTime = " + latestTime);
			System.out.println("latest = " + latest);
			
			/*
			 * 오늘 날짜
			 */
			Date date = new Date();
			String today = Integer.toString(date.getDate());
			System.out.println("today = " + today);
			
			
			if(latest.equals(today)) {
				out.print("<script language='javascript'>alert('이미 입실하셨습니다.')</script>");
				out.flush();
				System.out.println("이미 입실하셨습니다."); 
			} else {
				user_CheckService.updateInTime(user_Check);
				User_CheckVO latestInTime = user_CheckService.getLatestInTime(user_Check); // 유저 최근 입실시간 세션에 저장
				session.setAttribute("userInTime", latestInTime);
				out.print("<script language='javascript'>alert('입실했습니다.')</script>");
				out.flush();				
				System.out.println("입실등록 처리 성공 \n");
			}
			
			return "main.jsp";					
		} catch(NullPointerException e) {
			user_CheckService.setInTime(user_Check);
			User_CheckVO latestInTime = user_CheckService.getLatestInTime(user_Check); // 유저 최근 입실시간 세션에 저장
			session.setAttribute("userInTime", latestInTime);	
			out.print("<script language='javascript'>alert('입실했습니다.')</script>");
			out.flush();
			System.out.println("입실등록 처리 성공 \n");
			
			return "main.jsp";
		}
	}
	
	/*
	 * 퇴실등록
	 */
	@PostMapping("/setOutTime.do")
	public String setOutTime(User_CheckVO user_Check, UserVO user, HttpSession session,
			HttpServletResponse response) throws IOException {
		SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
				
		try {
			/*
			 * 최근 등록날짜
			 */
			User_CheckVO leave = user_CheckService.getLatestOutTime(user_Check);
			System.out.println(leave);
			Date leaveTime = leave.getOutTime();
			String latestTime = sf2.format(leaveTime);
			String latest = latestTime.substring(8,10);
			System.out.println("entrytime = " + leaveTime);
			System.out.println("latestTime = " + latestTime);
			System.out.println("latest = " + latest);
			
			/*
			 * 오늘 날짜
			 */
			Date date = new Date();
			String today = Integer.toString(date.getDate());
			System.out.println("today = " + today);
			
			
			if(latest.equals(today)) {
				out.print("<script language='javascript'>alert('이미 퇴실하셨습니다.')</script>");
				out.flush();
				System.out.println("이미 퇴실하셨습니다.");
				 
			} else {
				user_CheckService.updateOutTime(user_Check);			
				User_CheckVO latestOutTime = user_CheckService.getLatestOutTime(user_Check); // 유저 최근 퇴실시간 세션에 저장
				session.setAttribute("userOutTime", latestOutTime);
				out.print("<script language='javascript'>alert('퇴실했습니다.')</script>");
				out.flush();				
				System.out.println("퇴실등록 처리 성공 \n");
			}
			
			return "main.jsp";					
		} catch(NullPointerException e) {
			user_CheckService.setOutTime(user_Check);			
			User_CheckVO latestOutTime = user_CheckService.getLatestOutTime(user_Check); // 유저 최근 퇴실시간 세션에 저장
			session.setAttribute("userOutTime", latestOutTime);
			out.print("<script language='javascript'>alert('퇴실했습니다.')</script>");
			out.flush();
			System.out.println("퇴실등록 처리 성공 \n");
			
			return "main.jsp";
		}
	}
}
