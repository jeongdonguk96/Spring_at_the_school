package com.ezen.biz.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.BoardVO;
import com.ezen.biz.dto.UserCheckVO;
import com.ezen.biz.dto.UserVO;

@Service("userService")
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDAO userDAO;

	public UserServiceImpl() {}

	@Override
	public UserVO login(UserVO user) {
		return userDAO.login(user);
	}
	
	@Override
	public void logout() {
		userDAO.logout();
	}
	
	@Override
	public void insertUser(UserVO user) {
		userDAO.insertUser(user);
	}

	@Override
	public void updateUser(UserVO user) {
		userDAO.updateUser(user);
	}

	@Override
	public void deleteUser(UserVO user) {
		userDAO.deleteUser(user);
	}

	@Override
	public UserVO getUserInfo(UserVO user) {
		return userDAO.getUserInfo(user);
	}

	@Override
	public UserCheckVO getLatestEntry(UserVO user) {
		return userDAO.getLatestEntry(user);
	}

	@Override
	public UserCheckVO getLatestOut(UserVO user) {
		return userDAO.getLatestOut(user);
	}

	@Override
    public UserVO read(String id) throws Exception {
        return userDAO.selectUser(id);
    }
    @Override
    public List<UserVO> readAll() throws Exception {
        return userDAO.selectAllUser();
    }
    @Override
    public UserVO readAdmin(String id) throws Exception {
        return userDAO.selectAdmin(id);
    }
	
}
