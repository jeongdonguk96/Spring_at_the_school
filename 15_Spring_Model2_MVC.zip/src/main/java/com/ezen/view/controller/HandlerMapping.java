package com.ezen.view.controller;

import java.util.HashMap;
import java.util.Map;

/*
 * 모든 Controller 객체를 가지고 있으면서, 요청에 따라 맞는 Contorller를 검색하는 기능
 * HandlerMapping 객체는 DispatcherServlet이 사용하는 객체로, Dispathcer가 생성되고 init() 매서드가 호출될 때 한 번만 생성됨
 */
public class HandlerMapping {
	private Map<String, Controller> mappings; // 게시판 프로그램에 필요한 모든 Controller 객체들을 등록하고 관리
	
	public HandlerMapping() { // 이 곳에 요청path와 요청Controller를 매핑하여 저장한다
		mappings = new HashMap<String, Controller>();
		mappings.put("/login.do", new LoginController());
		mappings.put("/getBoardList.do", new GetBoardListController());
		mappings.put("/getBoard.do", new GetBoardController());
		mappings.put("/insertBoard.do", new InsertBoardController());
		mappings.put("/updateBoard.do", new UpdateBoardController());
		mappings.put("/deleteBoard.do", new DeleteBoardController());
		mappings.put("/logout.do", new LogoutController());
	}
	
	public Controller getController(String path) { // path에 해당해는 Controller 객체를 HashMap에서 검색 후 리턴
		return mappings.get(path);
	}
}
