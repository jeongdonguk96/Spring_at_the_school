package com.ezen.biz.view.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dto.BoardVO;

public class DeleteBoardController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 1. 사용자 입력 정보 추출
		int seq = Integer.parseInt(request.getParameter("seq"));
		
		// 2. DB 연동 후 처리
		BoardVO board = new BoardVO();
		board.setSeq(seq);
		
		BoardDAO boardDAO = new BoardDAO();
		boardDAO.deleteBoard(board);
		
		// 3. 화면 네비게이션
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("redirect:getBoardList.do"); // View에 정보 저장
		System.out.println("게시글 삭체 처리 완료 \n");
		
		return modelView;
	}

}
