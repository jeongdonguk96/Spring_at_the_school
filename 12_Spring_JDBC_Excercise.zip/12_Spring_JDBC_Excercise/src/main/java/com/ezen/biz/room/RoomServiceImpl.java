package com.ezen.biz.room;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.biz.dao.EquipmentDAO;
import com.ezen.biz.dao.RoomDAO;
import com.ezen.biz.dto.EquipmentVO;
import com.ezen.biz.dto.RoomVO;

@Service("roomService")
public class RoomServiceImpl implements RoomService {
	
	@Autowired
	private RoomDAO roomDAO;
	@Autowired
	private EquipmentDAO equipmentDAO;
	
	public int getMaxCapacity() {
		return roomDAO.findMaxCapacity();
	}
	
	public String getRoomNameById(String roomId) {
		return roomDAO.findRoomNameById(roomId);
	}
	
	public RoomVO getRoomById(String roomId) {

		return roomDAO.getRoomById(roomId);
	}
		
	public List<RoomVO> getAllRoom() {
		return roomDAO.getAllRoom();
	}
	
	public int insertRoom(RoomVO room) {
		int result = roomDAO.insertRoom(room); // insertRoom 실행
		
		if(result > 0) {
			for(EquipmentVO equip : room.getEquipmentList()) { // Tx연습을 위해 room을 생성할 때는 equipment를 같이 생성하도록 설계.
				equipmentDAO.insertEquipment(equip);
			}
		}
		
		return result;
	}
	
	public int updateRoomById(RoomVO room) {
		return roomDAO.updateRoomById(room);
	}
	
	public int deleteRoomById(RoomVO room) {
		return roomDAO.deleteRoomById(room);		
	}

}
