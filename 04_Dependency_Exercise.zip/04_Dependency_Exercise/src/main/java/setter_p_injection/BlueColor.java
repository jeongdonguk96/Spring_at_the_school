package setter_p_injection;

public class BlueColor implements Color {

	@Override
	public void printColor() {
		System.out.println("파란색입니다용!!");
	}

}
