package com.ezen.biz.dto;

import java.sql.Date;

public class UserVO {
	private String id; /* 아이디 */
	private String pwd; /* 패스워드 */
	private String name; /* 이름 */
	private Date regDate; /* 가입일 */
	private String role; /* 권한 */
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String password) {
		this.pwd = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "UserVO [id=" + id + ", pwd=" + pwd + ", name=" + name + ", regDate=" + regDate + ", role=" + role + "]";
	}
}
