package com.ezen.biz;

//import org.springframework.stereotype.Component;

//@Component("jbl")
public class JBLSpeaker implements Speaker {
	public JBLSpeaker() {
		System.out.println("===> JBLSpeaker 객체 생성 완료!!");
	}
	
	@Override
	public void volumeUp() {
		System.out.println("JBLSpeaker -- 볼륨을 올립니다.");
	}
	
	@Override
	public void volumeDown() {
		System.out.println("JBLSpeaker -- 볼륨을 내립니다.");
	}
}