package com.ezen.biz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.biz.SystemManager.EntranceManagerService;
import com.ezen.biz.dto.EntranceManagerVO;

@Controller
public class EntranceManagerController {
	
	@Autowired
	private EntranceManagerService entranceManagerService;
	
	/*
	 * 출석등록
	 */
	@RequestMapping("/registerEntranceTime.do")
	public String registerEntranceTime(EntranceManagerVO entranceManager) {
		entranceManagerService.registerEntranceTime(entranceManager);
		
		return "redirect:getMainPage.do";
	}
}
