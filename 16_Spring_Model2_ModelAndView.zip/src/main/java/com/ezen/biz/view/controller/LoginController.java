package com.ezen.biz.view.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserVO;

public class LoginController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 1. 사용자 입력 정보 추출
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		
		// 2. DB연동 후 처리
		UserVO uservo = new UserVO();
		uservo.setId(id);
		uservo.setPwd(pwd);
		
		UserDAO userDAO = new UserDAO();
		UserVO user = userDAO.getUser(uservo);
		
		// 3. 화면 응답 처리
		ModelAndView modelView = new ModelAndView();
		
		if(user != null) { // 로그인 성공 시
			modelView.setViewName("redirect:getBoardList.do"); // jsp화면이 아닐 시 redirect:를 붙여줘야 함
			System.out.println("로그인 처리 완료 \n");
		} else { 		   // 로그인 실패 시
			System.out.println("로그인 처리 실패 \n");
			modelView.setViewName("login");
		}
		
		return modelView;
	}

}
