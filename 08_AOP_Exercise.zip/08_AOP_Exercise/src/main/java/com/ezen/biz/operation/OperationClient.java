package com.ezen.biz.operation;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class OperationClient {

	public static void main(String[] args) {
		// 1. 스프링 컨테이너 구동
		AbstractApplicationContext container = new GenericXmlApplicationContext("applicationContext.xml");
		
		// 2. 스프링 컨테이너에 필요한 객체 요청(Lookup)
		Operation operation = (Operation) container.getBean("operation");
		
		System.out.println("message() 호출>>>");
		operation.message();
		
		System.out.println("m() 호출>>>");
		operation.m();
		
		System.out.println("k() 호출>>>");
		operation.k();
		
		container.close();
	}

}
