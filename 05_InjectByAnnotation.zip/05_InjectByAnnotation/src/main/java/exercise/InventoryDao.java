package exercise;

import org.springframework.stereotype.Component;

@Component
public class InventoryDao {
	
	public void printInventoryDaoStatus() {
		System.out.println("InventoryDao & status 메소드입니다.");
	}
}
