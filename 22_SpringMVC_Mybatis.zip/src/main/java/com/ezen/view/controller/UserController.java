package com.ezen.view.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.UserVO;

@Controller
public class UserController {

	/*
	 * 로그인 화면 출력
	 */
	@RequestMapping(value="/login.do", method=RequestMethod.GET)
	public String loginView(@ModelAttribute("user") UserVO  uservo) {
		
		uservo.setId("user1");
		uservo.setPassword("user1");
		
		return "login.jsp";
	}
	
	/*
	 * 로그인 처리
	 */
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public String login(UserVO vo, UserDAO userDao, ModelAndView modelView) {
		System.out.println("로그인 처리");
		
		if (vo.getId() == null || vo.getPassword().equals("")) {
			throw new IllegalArgumentException("아이디는 반드시 입력해야 합니다.");
		}
		
		UserVO user = userDao.getUser(vo);
		
		// 화면 응답 처리
		if (user != null) {  // 로그인 성공한 경우
			return "redirect:getBoardList.do";
		} else {
			return "login.jsp";
		}
	}
	
	/*
	 * 로그아웃 처리
	 */
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) throws Exception {
		session.invalidate();
		
		return "login.jsp";
	}
}
