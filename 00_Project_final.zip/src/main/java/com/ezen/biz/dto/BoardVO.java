package com.ezen.biz.dto;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class BoardVO {
	private int seq;					// 시퀀스(PRIMARY KEY)
	private String title;				// 글 제목
	private String writer;				// 글 작성자
	private String content;				// 글 내용
	private String fileName;			// 첨부파일 이름
	private Date regDate;				// 글 작성일
	private int readCnt;				// 글 조회수
	private String searchCondition;		// 글 검색 조건
	private String searchKeyword;		// 글 검색 키워드
	private MultipartFile uploadFile;	// 파일 업로드에 필요한 변수
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getReadCnt() {
		return readCnt;
	}
	public void setReadCnt(int readCnt) {
		this.readCnt = readCnt;
	}
	public String getSearchCondition() {
		return searchCondition;
	}
	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}
	public String getSearchKeyword() {
		return searchKeyword;
	}
	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}
	
	public MultipartFile getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}
	@Override
	public String toString() {
		return "BoardVO [seq=" + seq + ", title=" + title + ", writer=" + writer + ", content=" + content + ", regDate="
				+ regDate + ", readCnt=" + readCnt + ", searchCondition=" + searchCondition + ", searchKeyword=" + searchKeyword
				+ "]";
	}
	
}
