package constructor_injection;

public class Knife implements Weapon {
	
	public Knife() {}

	@Override
	public void useWeapon() {
		System.out.println("Use Knife");
	}

}
