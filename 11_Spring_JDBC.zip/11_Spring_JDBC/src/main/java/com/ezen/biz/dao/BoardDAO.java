package com.ezen.biz.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.BoardVO;

@Repository("boardDAO")
public class BoardDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/*
	 * 조회할 때 사용하는 RowMapper 인터페이스를 구현한 클래스
	 * 조회하는 작업을 따로 클래스로 떼내어 모듈화해서 사용하는 방식
	 */
	class BoardRowMapper implements RowMapper<BoardVO> {
		@Override
		public BoardVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			BoardVO board = new BoardVO();
			
			board.setSeq(rs.getInt("seq"));
			board.setTitle(rs.getString("title"));
			board.setWriter(rs.getString("writer"));
			board.setContent(rs.getString("content"));
			board.setRegDate(rs.getDate("reg_date"));
			board.setCount(rs.getInt("count"));
			
			return board;
		}	
	}
	
	/*
	 * SQL문은 상수 final
	 */
//	private static final String BOARD_INSERT = "INSERT INTO board(seq, title, writer, content) VALUES(board_seq.NEXTVAL, ?, ?, ?)";
	// 트랜잭션 처리 연습
	private static final String BOARD_INSERT = "INSERT INTO board(seq, title, writer, content) VALUES(?, ?, ?, ?)";
	private static final String BOARD_UPDATE = "UPDATE board SET(title=?, writer=?, content=?) WHERE seq=?";
	private static final String BOARD_DELETE = "DELETE FROM board WHERE seq=?";
	private static final String BOARD_LIST = "SELECT * FROM board";
	private static final String BOARD_GET = "SELECT * FROM board WHERE seq=?";
	
	// 글 등록 매서드
	public void insertBoard(BoardVO board) {
		System.out.println("===> JDBC로 insertBoard() 기능 처리");
		
		jdbcTemplate.update(BOARD_INSERT, board.getSeq(), board.getTitle(), board.getWriter(), board.getContent());
	}
	
	// 글 수정 매서드
	public void updateBoard(BoardVO board) {
		System.out.println("===> JDBC로 updateBoard() 기능 처리");
	
		Object[] args = {board.getTitle(), board.getWriter(), board.getContent(), board.getSeq()};
		
		jdbcTemplate.update(BOARD_UPDATE, args);
	}
	
	// 글 삭제 매서드
	public void deleteBoard(BoardVO board) {
		System.out.println("===> JDBC로 deleteBoard() 기능 처리");
		
		jdbcTemplate.update(BOARD_DELETE, board.getSeq());
	}
	
	// 글 전체 조회 매서드
	public List<BoardVO> getBoardList() {
		System.out.println("===> JDBC로 getBoardList() 기능 처리");
		List<BoardVO> boardList = jdbcTemplate.query(BOARD_LIST, new BoardRowMapper());
		
		return boardList;
	}
	
	// 글 상세 조회 매서드
	public BoardVO getBoard(BoardVO board) {
		System.out.println("===> JDBC로 getBoard() 기능 처리");
		Object[] args = {board.getSeq()};
		// 값이 바로 들어가면 오류. 값이 하나라도 배열 형식으로 들어가야 함

		return jdbcTemplate.queryForObject(BOARD_GET, args, new BoardRowMapper());
		// 이런 식으로 변수에 따로 값을 담지 않고 바로 값을 반환하는 방식도 가능
	}
}
