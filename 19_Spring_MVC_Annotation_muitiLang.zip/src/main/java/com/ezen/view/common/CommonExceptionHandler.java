package com.ezen.view.common;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice("com.ezen.view")
public class CommonExceptionHandler {
	
//	@ExceptionHandler(ArithmeticException.class)
//	public ModelAndView handleArithmeticException(Exception e) {
//		ModelAndView modelView = new ModelAndView();
//		modelView.addObject("exception", e);
//		modelView.setViewName("/common/arithmeticError.jsp");
//		
//		return modelView;
//	}
//	
//	@ExceptionHandler(NullPointerException.class)
//	public ModelAndView handleNullPointerException(Exception e) {
//		ModelAndView modelView = new ModelAndView();
//		modelView.addObject("exception", e);
//		modelView.setViewName("/common/nullPointerError.jsp");
//		
//		return modelView;
//	}
//	
//	@ExceptionHandler(Exception.class)
//	public ModelAndView handleException(Exception e) {
//		ModelAndView modelView = new ModelAndView();
//		modelView.addObject("exception", e);
//		modelView.setViewName("/common/error.jsp");
//		
//		return modelView;
//	}
}

// 이 방법을 사용하거나 presentation-layer.xml파일에 설정하는 방법이 있는데 xml에 설정하는 것이 더 편함