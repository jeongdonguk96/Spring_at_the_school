package com.ezen.biz.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.EquipmentVO;
import com.ezen.biz.dto.RoomVO;

@Repository("roomDAO")
public class RoomDAO {
	
	/*
	 * DB와 연동을 해줄 스프링JDBC 객체 생성 (스프링 컨테이너에 셋팅)
	 */
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private EquipmentDAO equipmentDAO;

	/*
	 * 조회할 때 사용하는 RowMapper 인터페이스를 구현한 클래스
	 * 조회하는 작업을 따로 클래스로 떼내어 모듈화해서 사용하는 방식
	 */
	class RoomRowMapper implements RowMapper<RoomVO> {
		@Override
		public RoomVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			RoomVO room = new RoomVO();
			
			room.setRoom_id(rs.getString("room_id"));
			room.setRoom_name(rs.getString("room_name"));
			room.setCapacity(rs.getInt("capacity"));
			
			return room;
		}	
	}
	
	/*
	 * SQL문은 상수 final
	 */
	private static final String SELECT_MAX_CAPACITY = "SELECT max(capacity) FROM room";
	private static final String GET_ROOM_NAME = "SELECT room_name FROM room WHERE room_id=?";
	private static final String GET_ROOM_INFO = "SELECT * FROM room WHERE room_id=?";
	private static final String GET_ALL_ROOM = "SELECT * FROM room";
	private static final String INSERT_ROOM = "INSERT INTO room VALUES(?, ?, ?)";
	private static final String UPDATE_ROOM = "UPDATE room SET(room_id=?, room_name=?, capacity=?) WHERE room_id=?";
	private static final String DELETE_ROOM = "DELETE FROM room WHERE room_id=?";
	
	// 모든 회의실 중 최대 수용인원 조회
	public int findMaxCapacity() {
		
		return jdbcTemplate.queryForObject(SELECT_MAX_CAPACITY, Integer.class);
	}
	
	// 회의실 번호를 조건으로 회의실 이름 조회
	public String findRoomNameById(String roomId) {
		Object[] args = {roomId};
		
		return jdbcTemplate.queryForObject(GET_ROOM_NAME, args, String.class);
	}
	
	// 회의실 번호를 조건으로 회의실 정보 조회
	public RoomVO getRoomById(String roomId) {
		Object[] args = {roomId};
		
		RoomVO room = jdbcTemplate.queryForObject(GET_ROOM_INFO, args, new RoomRowMapper()); // 회의실 번호를 조건으로 회의실 정보 조회
		
		List<EquipmentVO> equipmentList = equipmentDAO.getEquipmentById(roomId); // getRoomById() 매서드 사용 시 해당 room의 equipment의 정보도 담음
		
		room.setEquipmentList(equipmentList); // 위에서 담은 lv List변수를 room의 cv equipment변수에 담음
		
		return room; // 이 room에는 (1)번호로 조회한 회의실의 정보와 (2)그 희의실의 equipment 정보(부대시설) 2가지를 가짐 
	}
	
	// 모든 회의실 정보 조회
	public List<RoomVO> getAllRoom() {
		
		return jdbcTemplate.query(GET_ALL_ROOM, new RoomRowMapper());
	}
	
	// 회의실 추가
	public int insertRoom(RoomVO room) {	
		Object[] args = {room.getRoom_id(), room.getRoom_name(), room.getCapacity()};
		
		return jdbcTemplate.update(INSERT_ROOM, args);
	}
	
	// 회의실 번호를 조건으로 회의실 수정
	public int updateRoomById(RoomVO room) {
		Object[] args = {room.getRoom_id(), room.getRoom_name(), room.getCapacity(), room.getRoom_id()};
		
		return jdbcTemplate.update(UPDATE_ROOM, args);
	}
	
	// 회의실 번호를 조건으로 회의실 삭제
	public int deleteRoomById(RoomVO room) {
		
		return jdbcTemplate.update(DELETE_ROOM, room.getRoom_id());
	}

}
