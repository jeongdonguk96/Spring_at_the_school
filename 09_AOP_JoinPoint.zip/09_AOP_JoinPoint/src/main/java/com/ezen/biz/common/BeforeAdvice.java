package com.ezen.biz.common;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;

/*
 * 비즈니스 매서드에 적용할 로깅처리 클래스
 */
public class BeforeAdvice {
	public void beforeLog(JoinPoint jp) {
		// join point의 선언부 정보를 얻어오기 ※ join point : advice가 추가될 대상 매서드
		Signature sig = jp.getSignature(); // getSignature() : join point의 정보를 반환하는 매서드
		
		String method = sig.getName(); //  매서드명을 얻어온다.
		Object[] args = jp.getArgs(); // 매서드의 파라미터를 얻어온다.
		
		System.out.println("\n[사전 처리] 비즈니스 로직 수행 전 작업");
		System.out.print("이 매서드는 " + method);
		
		if(args.length == 0) { // 파라미터가 없는 경우
			System.out.println("()입니다");
		} else { // 파라미터가 있는 경우
			System.out.println("입니다\n" + "파라미터는 " + args[0] + "입니다");
		}
	}
}
