package setter_p_injection;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// 1. 스프링 컨테이너를 구동
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		Color color = (Color) factory.getBean("manager");
		
		color.printColor();
		
		factory.close();
	}

}
