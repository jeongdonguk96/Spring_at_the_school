package com.ezen.biz.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.biz.dto.BoardVO;

/*
 * SqlSessionDaoSupport 클래스를 상속하여 MyBatis 구현하는 방법
 */
@Repository("boardDAO")
public class BoardDAO extends SqlSessionDaoSupport {

	// 부모 클래스의 세션 생성 매서드를 호출해 데이터베이스에 연결할 세션을 생성
	@Autowired
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}
	
	// 글 등록 매서드
	public void insertBoard(BoardVO board) {
		System.out.println("===> MyBatis로 insertBoard() 처리");
		   				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		getSqlSession().insert("boardMapper.insertBoard", board);
	}
	
	// 글 수정 매서드
	public void updateBoard(BoardVO board) {
		System.out.println("===> MyBatis로 updateBoard() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		getSqlSession().update("boardMapper.updateBoard", board);
	}
	
	// 글 삭제 매서드
	public void deleteBoard(BoardVO board) {
		System.out.println("===> MyBatis로 deleteBoard() 처리");
				   // ("실행될 sql문의 id", parameterType으로 지정된 객체)
		getSqlSession().delete("boardMapper.deleteBoard", board);
	}
	
	// 글 전체 조회 매서드
	public List<BoardVO> getBoardList(BoardVO board) {
		System.out.println("===> MyBatis로 getBoardList() 처리");
									  // ("실행될 sql문의 id", returnType으로 지정된 객체)
		return getSqlSession().selectList("boardMapper.getBoardList", board);
	}
	
	// 글 상세 조회 매서드
	public BoardVO getBoard(BoardVO board) {
		System.out.println("===> MyBatis로 gettBoard() 처리");
				  					 // ("실행될 sql문의 id", returnType으로 지정된 객체)
		return getSqlSession().selectOne("boardMapper.getBoard", board);
		
	}
}















