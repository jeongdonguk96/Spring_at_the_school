package com.ezen.biz.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

@Service
@Aspect // 위빙의 역할
public class AroundAdvice {
	// @Pointcut("execution(* com.ezen.biz..*Impl.*(..))") // 포인트컷 생성
	// public void allPointCut() {}
	
	@Around("PointCutCommon.allPointCut()") // 포인트컷 지정
	public Object aroundLog(ProceedingJoinPoint pjp) throws Throwable {
		// 1. jp의 이름을 method에 저장
		String method = pjp.getSignature().getName();

		// 2. jp의 실행시간 측정을 위해 StopWatch() 객체 생성
		StopWatch stopWatch = new StopWatch();
		
		// 3. 비즈니스 매서드 시작시간 측정
		stopWatch.start();
				
		// 4. jp 실행 결과 returnObj에 저장
		Object returnObj = pjp.proceed();
		
		// 5. 비즈니스 매서드 종료시간 측정
		stopWatch.stop();
		
		System.out.printf("[AFTER] %s(), 수행에 걸린 시간 : %d(ms) \n", method, stopWatch.getTotalTimeMillis());
		
		return returnObj;
	}
}
