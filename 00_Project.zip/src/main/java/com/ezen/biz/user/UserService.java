package com.ezen.biz.user;

import com.ezen.biz.dto.UserVO;

public interface UserService {

	void insertUser(UserVO user);

}