package com.ezen.biz.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dao.UserDAO;
import com.ezen.biz.dto.BoardVO;
import com.ezen.biz.dto.UserVO;

public class DispatcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	private void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 1. 클리이언트 요청 path 정보를 추출한다. 마지막 "/" 뒤의 요청 command를 분리해서 path로 저장
		String uri = request.getRequestURI(); // uri : 쿼리스트링을 뺀 부분
		String path = uri.substring(uri.lastIndexOf('/')); // uri에서 마지막 '/'의 이후 부분을 path로 저장
		System.out.println("path(=command) : " + path);
		
		// 2. 클라이언트 요청 path에 따라 적절히 분기처리 한다.
		/*
		 * 로그인 처리
		 */
		if(path.equals("/login.do")) {
			// 1. 사용자 입력 정보 추출
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			
			// 2. DB 연동 처리
			UserVO vo = new UserVO();
			vo.setId(id);
			vo.setPwd(pwd);
			
			UserDAO userDAO = new UserDAO();
			UserVO user = userDAO.getUser(vo);
			
			// 3. 화면 네비게이션
			if(user != null) {
				response.sendRedirect("getBoardList.do");
			} else {
				response.sendRedirect("login.jsp");
			}			
			System.out.println("로그인 처리 완료");
			
	    /*
		 * 게시판 보기 처리
 		 */
		} else if(path.equals("/getBoardList.do")) {
			// 1. 사용자 입력 정보 추출
			// 2. DB 연동 처리
			BoardDAO boardDAO = new BoardDAO();
			List<BoardVO> boardList = boardDAO.getBoardList();
			
			// 3. 검색 결과를 세션에 저장하고 목록 화면으로 이동한다.
			HttpSession session = request.getSession();
			session.setAttribute("boardList", boardList);
			response.sendRedirect("getBoardList.jsp");
			System.out.println("게시판 보기 처리 완료");
			
		/*
		 * 게시글 상세보기 처리
		 */
		} else if(path.equals("/getBoard.do")) {
			// 1. 검색할 게시글 번호 추출
			int seq = Integer.parseInt(request.getParameter("seq"));
			
			// 2. DB 연동 처리
			BoardVO vo = new BoardVO();
			vo.setSeq(seq);
			
			BoardDAO boardDAO = new BoardDAO();
			BoardVO board = boardDAO.getBoard(vo);
			
			// 3. 응답 화면 구성
			HttpSession session = request.getSession();
			session.setAttribute("board", board);
			response.sendRedirect("getBoard.jsp");
			System.out.println("게시글 상세보기 화면 처리 완료");
		
	    /*
		 * 게시글 등록 처리
		 */
		} else if(path.equals("/insertBoard.do")) {
			// 1. 사용자 입력 정보 추출
			request.setCharacterEncoding("UTF-8");
			String title = request.getParameter("title");
			String writer = request.getParameter("writer");
			String content = request.getParameter("content");
			
			// 2. DB 연동 처리
			BoardVO board = new BoardVO();
			board.setTitle(title);
			board.setWriter(writer);
			board.setContent(content);
			
			BoardDAO boardDAO = new BoardDAO();
			boardDAO.insertBoard(board);
			
			// 3. 화면 네비게이션
			response.sendRedirect("getBoardList.jsp");
			System.out.println("게시글 등록 처리 완료");
		
		/*
		 *  게시글 수정 처리
		 */
		} else if(path.equals("/updateBoard.do")) {
			// 1. 사용자 입력 정보 추출
			request.setCharacterEncoding("UTF-8");
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			int seq = Integer.parseInt(request.getParameter("seq"));
			
			// 2. DB 연동 처리
			BoardVO board = new BoardVO();
			board.setTitle(title);
			board.setContent(content);
			board.setSeq(seq);
			
			BoardDAO boardDAO = new BoardDAO();
			boardDAO.updateBoard(board);
			
			// 3. 화면 네비게이션
			response.sendRedirect("getBoardList.jsp");
			System.out.println("게시글 수정 처리 완료");
		
		/*
		 * 게시글 삭제 처리
		 */
		} else if(path.equals("/deleteBoard.do")) {
			// 1. 사용자 입력 정보 추출
			int seq = Integer.parseInt(request.getParameter("seq"));

			// 2. DB 연동 처리
			BoardVO board = new BoardVO();
			board.setSeq(seq);
			
			BoardDAO boardDAO = new BoardDAO();
			boardDAO.deleteBoard(board);
			
			// 3. 화면 네비게이션
			response.sendRedirect("getBoardList.jsp");
			System.out.println("게시글 삭체 처리 완료");
			
		/*
		 * 로그아웃 처리
		 */
		} else if(path.equals("/logout.do")) {
			// 1. 브라우저와 연결된 세션 객체를 강제 종료한다.
			HttpSession session = request.getSession();
			session.invalidate();

			// 2. 세션 종료 후, 메인 화면으로 이동한다.
			response.sendRedirect("login.jsp");
		}
	}
}
