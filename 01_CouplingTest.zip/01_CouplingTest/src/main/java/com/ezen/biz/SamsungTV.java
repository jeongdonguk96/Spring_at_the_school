package com.ezen.biz;

public class SamsungTV {
	public void powerOn() {
		System.out.println("SamsungTV -- 전원을 켭니다");
	}
	public void powerOff() {
		System.out.println("SamsungTV -- 전원을 끕니다");
	}
	public void volumeUp() {
		System.out.println("SamsungTV -- 볼륨을 올립니다");
	}
	public void volumeDown() {
		System.out.println("SamsungTV -- 볼륨을 내립니다");
	}
}
