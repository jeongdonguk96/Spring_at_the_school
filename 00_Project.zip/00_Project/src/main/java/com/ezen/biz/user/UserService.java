package com.ezen.biz.user;

import com.ezen.biz.dto.UserVO;

public interface UserService {
	UserVO login(UserVO user);
	
	void logout();
	
	void insertUser(UserVO user);
	
	void updateUser(UserVO user);
	
	void deleteUser(UserVO user);
}