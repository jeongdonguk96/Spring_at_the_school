package com.ezen.view.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dto.BoardVO;

@Controller
public class BoardControllers {
	/*
	 * 글 목록 화면 조회
	 */
	@RequestMapping("/getBoardList.do") // "getBoardList.do" 라는 요청이 있을 때 사용할 매서드로 매핑
	public ModelAndView getBoardList(BoardDAO boardDAO, ModelAndView modelView) {
		// 1. DB에서 게시판 조회
		List<BoardVO> boardList = boardDAO.getBoardList();
		
		// 2. 검색 결과를 modelView 객체에 저장, 화면 응답 처리
		modelView.addObject("boardList", boardList);
		modelView.setViewName("getBoardList.jsp");
		System.out.println("게시판 화면 조회 완료 \n");
	
		return modelView;
	}
	
	/*
	 * 글 상세 화면 조회
	 */
	@RequestMapping("/getBoard.do")
	public ModelAndView getBoard(BoardVO board, BoardDAO boardDAO, ModelAndView modelView) {
		modelView.addObject("board", boardDAO.getBoard(board)); // Model에 데이터 정보 저장
		modelView.setViewName("getBoard.jsp"); // View에 응답화면 정보 저장
		System.out.println("게시글 상세보기 화면 조회 완료 \n");
		
		return modelView;
	}
	
	/*
	 * 글 등록 처리
	 */
	@RequestMapping("/insertBoard.do") // "insertBoard.do" 라는 요청이 있을 때 사용할 매서드로 매핑
	public ModelAndView insertBoard(BoardVO board, BoardDAO boardDAO, ModelAndView modelView) {
		boardDAO.insertBoard(board);
		
		modelView.setViewName("redirect:getBoardList.do"); // View에 정보 저장
		System.out.println("게시글 등록 처리 완료  \n");
		
		return modelView;
	}
	
	/*
	 * 글 수정 처리
	 */
	@RequestMapping("/updateBoard.do")
	public ModelAndView updateBoard(BoardVO board, BoardDAO boardDAO, ModelAndView modelView) {
		boardDAO.updateBoard(board);

		modelView.setViewName("redirect:getBoardList.do"); // View에 정보 저장
		System.out.println("게시글 수정 처리 완료 \n");
		
		return modelView;
	}
	
	/*
	 * 글 삭제 처리
	 */
	@RequestMapping("/deleteBoard.do")
	public ModelAndView deleteBoard(BoardVO board, BoardDAO boardDAO, ModelAndView modelView) {
		boardDAO.deleteBoard(board);
		
		modelView.setViewName("redirect:getBoardList.do"); // View에 정보 저장
		System.out.println("게시글 삭체 처리 완료 \n");
		
		return modelView;
	}
}
