package com.ezen.biz;

public class BoseSpeaker {
	public BoseSpeaker() {
		System.out.println("===> BoseSpeaker 객체 생성 완료!!");
	}
	
	public void volumeUp() {
		System.out.println("BoseSpeaker -- 볼륨을 올립니다.");
	}
	
	public void volumeDown() {
		System.out.println("BoseSpeaker -- 볼륨을 내립니다.");
	}
}
