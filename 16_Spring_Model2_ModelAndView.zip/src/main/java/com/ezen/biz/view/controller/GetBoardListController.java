package com.ezen.biz.view.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.ezen.biz.dao.BoardDAO;
import com.ezen.biz.dto.BoardVO;

public class GetBoardListController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 1. DB 연동 처리
		BoardDAO boardDAO = new BoardDAO();
		List<BoardVO> boardList = boardDAO.getBoardList();
		
		// 2. 검색 결과를 modelandview 객체에 저장
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("boardList", boardList); // Model에 정보 저장
		
		// 3. 화면 응답 처리
		modelView.setViewName("getBoardList"); // View에 정보 저장
		System.out.println("게시판 보기 처리 완료 \n");
	
		return modelView;
	}

}
