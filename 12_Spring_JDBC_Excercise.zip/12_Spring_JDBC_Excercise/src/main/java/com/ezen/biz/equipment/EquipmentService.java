package com.ezen.biz.equipment;

import com.ezen.biz.dto.EquipmentVO;

public interface EquipmentService {

	void insertEquipment(EquipmentVO equip);

	int updateEquipmentById(EquipmentVO equip);

	int deleteEquipmentById(EquipmentVO equip);

}