package com.ezen.biz.common;

import org.aspectj.lang.ProceedingJoinPoint;

public class AroundAdvice {
	public Object aroundLog(ProceedingJoinPoint pjp) throws Throwable {
		// 1. 비즈니스 매서드 수행 전 BeforeAdvice 실행 
		System.out.println("[BEFORE]: 비즈니스 메소드 수행 전에 처리할 내용...");
		
		// 2. 수행이 끝난 비즈니스 매서드를 호출해서 실행
		Object returnObj = pjp.proceed();
		
		// 3. 비즈니스 매서드 수행 후 AfterAdvice 실행
		System.out.println("[AFTER]: 비즈니스 메소드 수행 후에 처리할 내용...");
		
		// 4. 
		return returnObj;
	}
}
