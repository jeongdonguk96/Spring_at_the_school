package com.ezen.biz;

public class LgTV {
	public void turnOn() {
		System.out.println("LgTv -- 전원을 켭니다");
	}
	public void turnOff() {
		System.out.println("LgTv -- 전원을 끕니다");
	}
	public void soundUp() {
		System.out.println("LgTv -- 볼륨을 올립니다");
	}
	public void soundDown() {
		System.out.println("LgTv -- 볼륨을 내립니다");
	}
}
