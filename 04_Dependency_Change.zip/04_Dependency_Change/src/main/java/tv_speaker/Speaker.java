package tv_speaker;

public interface Speaker {
	public void volumeUp();
	public void volumeDown();
}
